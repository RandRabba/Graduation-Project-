const $ = s => document.querySelector(s);
// الوضع الفاتح/الداكن يُختار من الملف الشخصي ← التفضيلات، ويُحفظ في المتصفح (header.php يطبّقه قبل عرض الصفحة)
const root = document.documentElement;
const setTheme = t => {
  root.dataset.theme = t;
  try { localStorage.setItem('dms-theme', t); } catch (e) {}
};

// القائمة الجانبية على الجوال تفتح كدرج من اليسار
const side = $('#side'), menu = $('#menu'), scrim = $('#scrim');
const setMenu = open => {
  document.body.classList.toggle('menu-open', open);
  scrim.hidden = !open;
  menu.setAttribute('aria-expanded', open);
  if (open) side.querySelector('nav a').focus();
};
menu.onclick = () => setMenu(!document.body.classList.contains('menu-open'));
scrim.onclick = () => setMenu(false);
addEventListener('keydown', e => { if (e.key === 'Escape' && document.body.classList.contains('menu-open')) { setMenu(false); menu.focus(); } });

// نصوص الواجهة المترجمة يرسلها header.php في window.I18N
const T = (k, a = {}) => Object.entries(a).reduce((s, [n, v]) => s.replace(`{${n}}`, v), (window.I18N || {})[k] || k);

// التحية حسب وقت جهاز الطبيبة (فقط في صفحة لوحة التحكم)
const g = $('#greet'), hr = new Date().getHours();
if (g.dataset.name) g.textContent = T(`dash.greet.${hr < 12 ? 'morning' : hr < 18 ? 'afternoon' : 'evening'}`, { name: g.dataset.name });

// بحث عام: يصفّي أي عنصر عليه data-s
$('#search').oninput = e => {
  const q = e.target.value.trim().toLowerCase();
  document.querySelectorAll('[data-s]').forEach(el => el.hidden = q && !el.dataset.s.includes(q));
};

// التبويبات
document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => {
  document.querySelectorAll('.tabs button').forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.tab').forEach(t => t.hidden = t.id !== b.dataset.tab);
  history.replaceState(null, '', '#' + b.dataset.tab);
});
const t0 = location.hash.slice(1), tb = t0 && document.querySelector(`.tabs button[data-tab="${t0}"]`);
if (tb) tb.click();
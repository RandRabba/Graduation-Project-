// المصدر والتصنيف يأتيان جاهزين ومترجمين من api.php حتى يبقى التصنيف موحداً في كل الصفحات
let readings = [];

const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

// قيمة لا يمكن حسابها (لا توجد قراءات) تظهر "—"
const dash = (v, unit = '') => v === null || v === undefined ? '—' : `${v}${unit}`;

function renderStats(s) {
  const cards = [
    ['c-avg',ICONS.drop,T('card.avg'), s.avg === null ? '—' : `${s.avg} <span>${esc(T('unit.mgdl'))}</span>`],
    ['c-ok',ICONS.clock,T('card.tir'), dash(s.tir, '%')],
    ['c-ctrl',ICONS.alert,T('card.high'), dash(s.high, '%')],
    ['c-high',ICONS.drop,T('card.low'), dash(s.low, '%')],
    ['c-info',ICONS.report,T('card.total'), s.total],
  ];
  $('#stats').innerHTML = cards.map(c => `<div class="card ${c[0]}"><div class="ico">${c[1]}</div><div><small>${esc(c[2])}</small><b>${c[3]}</b></div></div>`).join('');
}

function renderList() {
  const q = $('#search').value.trim().toLowerCase();
  if (!readings.length) { $('#list').innerHTML = `<p class="empty">${esc(T('empty.readings'))}</p>`; return; }
  const rows = readings.filter(r => !q || `${r.title} ${r.sub} ${r.v} ${r.label}`.toLowerCase().includes(q));
  $('#list').innerHTML = rows.length ? rows.map(r => `
    <a class="row ${esc(r.st)}" href="patient.php?id=${encodeURIComponent(r.pid)}#t-rd">
      <div class="who"><div class="ico">${r.icon}</div><div><b>${esc(r.title)}</b><small>${esc(r.sub)}</small></div></div>
      <div class="val"><b>${esc(r.v)}</b> <span>${esc(T('unit.mgdl'))}</span><div class="when">${esc(r.date)} · ${esc(r.time)}</div></div>
      <div class="stat"><span class="pill">${esc(r.label)}</span><span class="rng">(<bdi dir="ltr">${esc(r.range)}</bdi>)</span></div>
      <span>${esc(T('common.chev'))}</span>
    </a>`).join('') : `<p class="empty">${esc(T('js.nomatch'))}</p>`;
}

async function load(id) {
  try {
    const res = await fetch(`api.php?patient=${id}`);
    if (!res.ok) throw new Error(res.status);
    const d = await res.json();
    readings = d.readings;
    renderStats(d.stats);
    renderList();
  } catch (e) {
    $('#list').innerHTML = `<p class="empty">${esc(T('js.loaderr'))}</p>`;
  }
}

$('#patient').onchange = e => load(e.target.value);
$('#search').oninput = renderList;
load($('#patient').value);

<?php
require_once __DIR__.'/data.php';
$page='alerts'; $title=t('nav.alerts'); $heading=t('nav.alerts'); $sub=t('al.sub');
require __DIR__.'/header.php';
$all=getPatients(); $sel=(int)($_GET['p']??0);
$items=[];
foreach($all as $id=>$p){ if($sel && $sel!==$id) continue;
  // كل تنبيه في مجموعة واحدة من اثنتين (SR6.2): حرج = المستوى 2 (طارئ)، مضبوط = أي قراءة غير طبيعية أخرى
  // (المنخفض 54–69 والمرتفع فوق الهدف). العنوان يبقى يذكر نوع القراءة الفعلي، مثل "قراءة منخفضة"
  foreach($p['alerts'] as $i=>$a) $items[]=['pid'=>$id,'i'=>$i,'t'=>$a['st']==='crit'?'crit':'ctrl','x'=>alertTitle($a),'w'=>ldate('M d, Y · h:i A',$a['at']),'pt'=>$p['name'],'ack'=>$_SESSION['ack'][$id][$i]??null,'ts'=>$a['at']]; }
// غير المراجَعة أولاً، ثم الحرجة، ثم الأحدث
usort($items, fn($a,$b)=>[(bool)$a['ack'],$a['t']!=='crit',-$a['ts']]<=>[(bool)$b['ack'],$b['t']!=='crit',-$b['ts']]);
$n=count($items); $nOpen=count(array_filter($items,fn($x)=>!$x['ack']));
$nCrit=count(array_filter($items,fn($x)=>!$x['ack']&&$x['t']==='crit'));
?>
  <div class="bar"><h2><?= t('al.count',['n'=>'<span id="cnt">'.$n.'</span>']) ?></h2>
    <div class="ctl">
      <div class="seg" role="group" aria-label="<?= tt('al.filter') ?>">
        <button data-f="all" class="on"><?= tt('common.all') ?></button><?php foreach(['ok','ctrl','crit'] as $k): ?><button data-f="<?= $k ?>"><?= h(PST[$k]) ?></button><?php endforeach; ?>
      </div>
      <form method="get"><select name="p" onchange="this.form.submit()" aria-label="<?= tt('common.select_patient') ?>">
        <option value="0"><?= tt('common.all_patients') ?></option>
        <?php foreach($all as $k=>$x): ?><option value="<?= $k ?>" <?= $sel===$k?'selected':'' ?>><?= h($x['name']) ?></option><?php endforeach; ?>
      </select></form></div></div>

  <section class="stats">
    <div class="card c-ctrl"><div class="ico"><?= ic('bell') ?></div><div><small><?= tt('al.card.open') ?></small><b><?= $nOpen ?></b></div></div>
    <div class="card c-high"><div class="ico"><?= ic('alert') ?></div><div><small><?= tt('al.card.crit') ?></small><b><?= $nCrit ?></b></div></div>
    <div class="card c-ok"><div class="ico"><?= ic('check') ?></div><div><small><?= tt('al.card.rev') ?></small><b><?= $n-$nOpen ?></b></div></div>
    <div class="card c-info"><div class="ico"><?= ic('report') ?></div><div><small><?= tt('al.card.total') ?></small><b><?= $n ?></b></div></div>
  </section>

  <h2 class="sub"><?= tt('al.list') ?></h2>
  <section class="list" id="al">
    <?php foreach($items as $a): ?>
      <div class="row <?= $a['t'] ?> <?= $a['ack']?'done':'' ?>" data-t="<?= $a['t'] ?>" data-s="<?= h(mb_strtolower($a['x'].' '.$a['pt'].' '.PST[$a['t']])) ?>">
        <div class="who"><div class="ico"><?= ic('alert') ?></div><div><b><?= h($a['x']) ?></b><small><a href="patient.php?id=<?= $a['pid'] ?>#t-al" dir="auto"><?= h($a['pt']) ?></a></small></div></div>
        <div class="val"><span><?= h($a['w']) ?></span></div>
        <div class="stat"><span class="pill"><?= h(PST[$a['t']]) ?></span></div>
        <div class="act">
          <?php $rv='patient.php?id='.$a['pid'].'&alert='.$a['i'].($sel?'&p='.$sel:'').'#t-rd'; ?>
          <?php if($a['ack']): ?><small><?= tt('al.reviewed',['d'=>ldate('M d · h:i A',$a['ack'])]) ?></small> <a class="lnk" href="<?= h($rv) ?>"><?= tt('al.view') ?></a>
          <?php else: ?><a class="btn sm" href="<?= h($rv) ?>"><?= tt('al.review') ?></a><?php endif; ?>
        </div>
      </div>
    <?php endforeach; if(!$items) echo '<p class="empty">'.tt('al.none').'</p>'; ?>
    <?php // رسالة عندما لا يطابق الفلتر أي تنبيه (مثلاً "طبيعي": التنبيهات تُنشأ للقراءات غير الطبيعية فقط) ?>
    <?php if($items): ?><p class="empty" id="nofilt" hidden><?= tt('al.none_filter') ?></p><?php endif; ?>
  </section>
  <script>
    document.querySelectorAll('.seg button').forEach(b=>b.onclick=()=>{
      document.querySelectorAll('.seg button').forEach(x=>x.classList.toggle('on',x===b));
      let c=0; document.querySelectorAll('#al [data-t]').forEach(r=>{const ok=b.dataset.f==='all'||r.dataset.t===b.dataset.f; r.style.display=ok?'':'none'; if(ok)c++});
      document.getElementById('cnt').textContent=c;
      const nf=document.getElementById('nofilt'); if(nf) nf.hidden=c>0;
    });
  </script>
<?php require __DIR__.'/footer.php'; ?>

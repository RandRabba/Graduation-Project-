<?php
require_once __DIR__.'/data.php';
$page='dashboard'; $title=t('dash.title'); $js='app.js';
$greet=getDoctor()['name'];
$heading=t('dash.greet.morning',['name'=>$greet]); $sub=t('dash.sub');
require __DIR__.'/header.php';
?>
  <div class="bar">
    <h2><?= tt('dash.overview') ?></h2>
    <select id="patient" aria-label="<?= tt('common.select_patient') ?>">
      <?php foreach (getPatients() as $p): ?><option value="<?= $p['id'] ?>"><?= h($p['name']) ?></option><?php endforeach; ?>
    </select>
  </div>
  <section class="stats" id="stats"></section>
  <h2 class="sub"><?= tt('dash.recent') ?></h2>
  <section class="list" id="list" aria-live="polite"></section>
<?php require __DIR__.'/footer.php'; ?>

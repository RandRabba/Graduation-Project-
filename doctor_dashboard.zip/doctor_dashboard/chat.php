<?php
require_once __DIR__.'/data.php';
$all=getPatients(); $id=(int)($_GET['p']??1); if(!isset($all[$id])) $id=1; $p=$all[$id];
// المراسلة متاحة لكل مريض مسند للطبيبة (لا يوجد نظام اشتراكات)
if($_SERVER['REQUEST_METHOD']==='POST' && trim($_POST['text']??'')!==''){
  $_SESSION['chat'][$id] ??= [];
  $_SESSION['chat'][$id][] = ['doctor', trim($_POST['text']), time()];
  header("Location: chat.php?p=$id"); exit;
}
$page='chat'; $title=t('nav.chat'); $heading=t('nav.chat'); $sub=t('chat.sub');
require __DIR__.'/header.php';
?>
<div class="chatbox">
  <aside class="plist">
    <?php foreach($all as $k=>$x): $c=getChat($k); $lm=end($c); $wait=$lm && $lm[0]==='patient'; ?>
      <a href="chat.php?p=<?= $k ?>" class="pt <?= $k===$id?'on':'' ?>" data-s="<?= h(mb_strtolower($x['name'])) ?>">
        <div class="avatar"><?= h(initials($x['name'])) ?></div>
        <div class="pm"><b dir="auto"><?= h($x['name']) ?></b><small dir="auto"><?= $lm ? ($lm[0]==='doctor' ? tt('chat.you',['m'=>$lm[1]]) : h($lm[1])) : tt('chat.none') ?></small></div>
        <?php if($wait): ?><span class="pill b-ctrl"><?= tt('chat.reply') ?></span><?php endif; ?>
      </a>
    <?php endforeach; ?>
  </aside>

  <section class="conv">
    <div class="chead">
      <div class="avatar"><?= h(initials($p['name'])) ?></div>
      <div><b dir="auto"><?= h($p['name']) ?></b><small><?= h(patientMeta($p)) ?></small></div>
      <?= statusPill($p['status']) ?>
      <a class="btn ghost" href="patient.php?id=<?= $id ?>"><?= tt('chat.file') ?></a>
    </div>
    <div class="msgs" id="msgs">
      <?php foreach(getChat($id) as $m): ?>
        <div class="b <?= $m[0] ?>"><p dir="auto"><?= nl2br(h($m[1])) ?></p><small><?= h(ldate('h:i A',$m[2])) ?></small></div>
      <?php endforeach; if(!getChat($id)) echo '<p class="empty">'.tt('chat.start',['name'=>$p['name']]).'</p>'; ?>
    </div>
    <form method="post" class="comp">
      <textarea name="text" id="msg" rows="1" dir="auto" required placeholder="<?= tt('chat.ph') ?>"></textarea>
      <button class="btn" type="submit"><?= tt('chat.send') ?></button>
    </form>
  </section>
</div>
<script>
  const box=document.getElementById('msgs'); box.scrollTop=box.scrollHeight;
  const t=document.getElementById('msg');
  if(t) t.addEventListener('keydown',e=>{ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); if(t.value.trim()) t.form.submit(); } });
</script>
<?php require __DIR__.'/footer.php'; ?>

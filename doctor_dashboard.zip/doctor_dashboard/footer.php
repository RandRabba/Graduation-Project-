</main>
<script src="common.js"></script>
<?php if (!empty($js)) echo '<script src="'.h($js).'"></script>'; ?>
</body>
</html>
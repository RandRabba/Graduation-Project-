<?php
require_once __DIR__.'/data.php';
$page='glucose'; $title=t('nav.glucose'); $heading=t('nav.glucose'); $sub=t('glu.sub');
require __DIR__.'/header.php';
$all=getPatients(); $id=(int)($_GET['p']??1); if(!isset($all[$id])) $id=array_key_first($all); $p=$all[$id]; $tg=targets($p);
// الفترة والمصدر في الرابط حتى تتحدث البطاقات والرسم والتوزيع والسجل معاً عند أي تغيير
$RANGES=['24h'=>1,'7d'=>7,'14d'=>14,'30d'=>30];
$rk=array_key_exists($_GET['r']??'',$RANGES)?$_GET['r']:'14d'; $days=$RANGES[$rk];
$src=in_array($_GET['src']??'',['cgm','manual'],true)?$_GET['src']:'all';
$url=fn(array $q)=>'glucose.php?'.http_build_query(array_replace(['p'=>$id,'r'=>$rk,'src'=>$src],$q));
$to=time(); $from=$to-$days*86400;
$period=array_values(array_filter($p['readings'],fn($r)=>$r['at']>$from));
$ns=count(array_filter($period,fn($r)=>$r['src']==='cgm')); $nm=count($period)-$ns;
$rs=$src==='all'?$period:array_values(array_filter($period,fn($r)=>$r['src']===$src));
$st=glucoseStats($rs,$tg);
// الوقت ضمن النطاق دائماً من قراءات الحساس (CGM) في الفترة، بغض النظر عن فلتر المصدر
$cg=glucoseStats($period,$tg); $bd=tirBreakdown($period,$tg);
// تغطية الحساس: عدد أجزاء الـ 24 ساعة من الفترة التي فيها قراءات حساس (يُنصح بـ 70% على الأقل)
$covDays=count(array_unique(array_map(fn($r)=>(int)(($r['at']-$from)/86400),array_filter($period,fn($r)=>$r['src']==='cgm'))));
$covPct=$days>1?round($covDays/$days*100):null;

// ===== الرسم البياني: محور زمني حقيقي، ومحور قيم بخطوط الأهداف =====
$L=50;$R=704;$T=14;$B=204;$V0=40;$V1=320;
$X=fn($t)=>round($L+($t-$from)/($to-$from)*($R-$L),1);
$Y=fn($v)=>round($B-(max($V0,min($V1,$v))-$V0)/($V1-$V0)*($B-$T),1);
$asc=array_reverse($rs);
// خط الحساس يُقطع إذا كانت الفجوة أكثر من 8 ساعات حتى لا يوحي بقراءات غير موجودة
$segs=[];$cur=[];$prev=null;
foreach($asc as $r){ if($r['src']!=='cgm') continue;
  if($prev!==null && $r['at']-$prev>8*3600){ if(count($cur)>1) $segs[]=$cur; $cur=[]; }
  $cur[]=$X($r['at']).','.$Y($r['v']); $prev=$r['at']; }
if(count($cur)>1) $segs[]=$cur;
$ticks=[];
if($days===1){ for($t=strtotime(date('Y-m-d H:00:00',$from))+3600;$t<=$to;$t+=3600) if((int)date('G',$t)%3===0) $ticks[]=[$t,ldate('g A',$t)]; }
else { $step=$days<=7?1:($days<=14?2:5); for($t=strtotime('tomorrow',$from),$i=0;$t<=$to;$t=strtotime('+1 day',$t),$i++) if($i%$step===0) $ticks[]=[$t,ldate('M d',$t)]; }
$lo=$rs?array_reduce($rs,fn($a,$r)=>$a===null||$r['v']<$a['v']?$r:$a):null;
$hi=$rs?array_reduce($rs,fn($a,$r)=>$a===null||$r['v']>$a['v']?$r:$a):null;
$rad=count($rs)>80?2.2:3.4;
$tip=fn($r)=>h($r['v'].' mg/dL · '.ldate('M d, h:i A',$r['at']).' · '.GSRC[$r['src']][1].' · '.PST[$r['st']]);
// النطاقات الخمسة وأهدافها (التوافق الدولي أو أهداف المريض الفردية)
$B5=['vhigh'=>['> '.$tg['vhigh'],'lt',$tg['tar2']],'high'=>[($tg['high']+1).'–'.$tg['vhigh'],'lt',$tg['tar']],
     'in'=>[$tg['low'].'–'.$tg['high'],'gt',$tg['tir']],'low'=>[$tg['vlow'].'–'.($tg['low']-1),'lt',$tg['tbr']],'vlow'=>['< '.$tg['vlow'],'lt',$tg['tbr2']]];
?>
  <div class="bar"><h2><?= t('glu.count',['name'=>h($p['name']),'n'=>'<span id="cnt">'.count($rs).'</span>']) ?></h2>
    <div class="ctl">
      <div class="seg" role="group" aria-label="<?= tt('glu.range') ?>">
        <?php foreach($RANGES as $k=>$_): ?><a href="<?= h($url(['r'=>$k])) ?>" class="<?= $k===$rk?'on':'' ?>"<?= $k===$rk?' aria-current="true"':'' ?>><?= tt('glu.r.'.$k) ?></a><?php endforeach; ?>
      </div>
      <div class="seg" role="group" aria-label="<?= tt('glu.filter') ?>">
        <?php foreach(['all'=>[tt('common.all'),count($period)],'cgm'=>[tt('glu.sensor'),$ns],'manual'=>[tt('glu.manual'),$nm]] as $k=>[$lb,$c]): ?><a href="<?= h($url(['src'=>$k])) ?>" class="<?= $k===$src?'on':'' ?>"<?= $k===$src?' aria-current="true"':'' ?>><?= $lb ?> <em><?= $c ?></em></a><?php endforeach; ?>
      </div>
      <form method="get"><input type="hidden" name="r" value="<?= $rk ?>"><input type="hidden" name="src" value="<?= $src ?>">
        <select name="p" onchange="this.form.submit()" aria-label="<?= tt('common.select_patient') ?>">
        <?php foreach($all as $k=>$x): ?><option value="<?= $k ?>" <?= $k===$id?'selected':'' ?>><?= h($x['name']) ?></option><?php endforeach; ?>
      </select></form>
    </div></div>
  <p class="tgline"><?= h(patientMeta($p)) ?> · <?= tt('glu.target') ?> <?= ltr($tg['low'].'–'.$tg['high'].' mg/dL') ?> · <?= tt('glu.goal') ?> <?= ltr('> '.$tg['tir'].'%') ?></p>

  <section class="stats">
    <div class="card c-info"><div class="ico"><?= ic('report') ?></div><div><small><?= tt('glu.card.total') ?></small><b><?= count($rs) ?></b></div></div>
    <div class="card c-avg"><div class="ico"><?= ic('drop') ?></div><div><small><?= tt('glu.card.avg') ?></small><b><?= $st['avg']===null?'—':$st['avg'].' <span>'.tt('unit.mgdl').'</span>' ?></b></div></div>
    <div class="card c-ok"><div class="ico"><?= ic('clock') ?></div><div><small><?= tt('glu.card.tir') ?></small><b><?= dash($cg['tir'],'%') ?></b><small class="csub"><?= tt('glu.card.tir_sub',['g'=>$tg['tir']]) ?></small></div></div>
    <div class="card c-ctrl"><div class="ico"><?= ic('swap') ?></div><div><small><?= tt('glu.card.sm') ?></small><b><?= ltr($ns.' / '.$nm) ?></b></div></div>
  </section>

  <h2 class="sub"><?= tt('glu.over_time') ?></h2>
  <svg class="chart gchart" viewBox="0 0 720 232" role="img" aria-label="<?= tt('glu.chart') ?>">
    <rect x="<?= $L ?>" y="<?= $Y($tg['high']) ?>" width="<?= $R-$L ?>" height="<?= $Y($tg['low'])-$Y($tg['high']) ?>" class="band"/>
    <?php $ly=[]; foreach([$tg['low'],$tg['high'],$tg['vlow'],$tg['vhigh']] as $g): ?>
      <line x1="<?= $L ?>" x2="<?= $R ?>" y1="<?= $Y($g) ?>" y2="<?= $Y($g) ?>" class="grid<?= in_array($g,[$tg['vlow'],$tg['vhigh']])?' lim':'' ?>"/>
      <?php // حدود النطاق المستهدف تُكتب أولاً، و54/250 فقط إن لم تتداخل معها
      if(!array_filter($ly,fn($y)=>abs($y-$Y($g))<12)): $ly[]=$Y($g); ?><text x="<?= $L-6 ?>" y="<?= $Y($g)+4 ?>" text-anchor="end" class="ax"><?= $g ?></text><?php endif; ?>
    <?php endforeach; ?>
    <line x1="<?= $L ?>" x2="<?= $R ?>" y1="<?= $B ?>" y2="<?= $B ?>" class="grid"/>
    <?php foreach($ticks as [$t,$lb]): ?><line x1="<?= $X($t) ?>" x2="<?= $X($t) ?>" y1="<?= $B ?>" y2="<?= $B+4 ?>" class="grid"/><text x="<?= $X($t) ?>" y="<?= $B+18 ?>" text-anchor="middle" class="ax"><?= h($lb) ?></text><?php endforeach; ?>
    <text x="<?= $L-6 ?>" y="<?= $T-2 ?>" text-anchor="end" class="ax">mg/dL</text>
    <?php if($rs): ?>
      <?php foreach($segs as $s): ?><polyline class="cgm" points="<?= implode(' ',$s) ?>"/><?php endforeach; ?>
      <?php foreach($asc as $r): $x=$X($r['at']); $y=$Y($r['v']); ?>
        <?= $r['src']==='cgm'
          ? '<circle cx="'.$x.'" cy="'.$y.'" r="'.$rad.'" class="dot"><title>'.$tip($r).'</title></circle>'
          : '<rect x="'.($x-4).'" y="'.($y-4).'" width="8" height="8" class="mdot"><title>'.$tip($r).'</title></rect>' ?>
      <?php endforeach; ?>
      <?php foreach([$hi,$lo] as $m): ?><text x="<?= $X($m['at']) ?>" y="<?= $m===$hi?$Y($m['v'])-8:$Y($m['v'])+16 ?>" text-anchor="middle" class="mm"><?= h($m['v']) ?></text><?php endforeach; ?>
    <?php else: ?><text x="377" y="100" text-anchor="middle" class="ax"><?= tt('glu.none_period') ?></text><?php endif; ?>
  </svg>
  <small class="note"><span class="lg dotk"></span> <?= tt('src.cgm') ?> &nbsp; <span class="lg sqk"></span> <?= tt('glu.manual') ?> &nbsp;· <?= tt('glu.band_note') ?> <?= ltr($tg['low'].'–'.$tg['high'].' mg/dL') ?></small>

  <h2 class="sub"><?= tt('glu.tir_title') ?></h2>
  <?php if($bd): ?>
    <div class="tir">
      <div class="tirbar" role="img" aria-label="<?= tt('glu.tir_title') ?>"><?php foreach(array_reverse($B5,true) as $k=>$_) if($bd['pct'][$k]>0) echo '<i class="t-'.$k.'" style="width:'.round($bd['pct'][$k],1).'%"></i>'; ?></div>
      <div class="tirleg">
        <?php foreach($B5 as $k=>[$rng,$op,$goal]): ?>
          <div><i class="sw t-<?= $k ?>"></i><span><?= tt('glu.t.'.$k) ?> <small><?= ltr($rng.' mg/dL') ?></small></span><b class="<?= $bd['met'][$k]?'met':'miss' ?>"><?= round($bd['pct'][$k]) ?>%</b><small><?= tt('glu.goal_'.$op,['v'=>$goal]) ?></small></div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php if($covPct!==null): ?><small class="note"><?= tt('glu.coverage',['d'=>$covDays,'n'=>$days]) ?></small>
      <?php if($covPct<70): ?><p class="warn tirwarn"><?= tt('glu.coverage_low') ?></p><?php endif; ?><?php endif; ?>
  <?php else: ?><p class="txt"><?= tt('glu.no_cgm') ?></p><?php endif; ?>

  <h2 class="sub"><?= tt('glu.history') ?></h2>
  <section class="list" id="hist">
    <?php foreach($rs as $r): $sen=$r['src']==='cgm'; ?>
      <div class="row <?= $r['st'] ?>" data-k="<?= $r['src'] ?>" data-s="<?= h(mb_strtolower(GSRC[$r['src']][1].' '.($r['type']??'').' '.$r['v'].' '.PST[$r['st']])) ?>">
        <div class="who"><div class="ico"><?= GSRC[$r['src']][0] ?></div><div><b><?= h(GSRC[$r['src']][1]) ?></b><small><?= h($r['type']??'') ?></small></div></div>
        <div class="val"><b><?= h($r['v']) ?></b> <span><?= tt('unit.mgdl') ?></span><div class="when"><?= h(ldate('M d, Y · h:i A',$r['at'])) ?></div></div>
        <div class="stat"><span class="src s-<?= $sen?'sensor':'manual' ?>"><?= tt($sen?'glu.sensor':'glu.manual') ?></span> <span class="pill"><?= h(PST[$r['st']]) ?></span><span class="rng">(<?= ltr(stRange($r['st'],$tg,(int)$r['v'])) ?>)</span></div>
        <span></span></div>
    <?php endforeach; if(!$rs) echo '<p class="empty">'.tt('glu.none_period').'</p>'; ?>
  </section>
<?php require __DIR__.'/footer.php'; ?>

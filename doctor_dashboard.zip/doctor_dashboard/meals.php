<?php
require_once __DIR__.'/data.php';
$page='meals'; $title=t('nav.meals'); $heading=t('nav.meals'); $sub=t('meals.sub');
require __DIR__.'/header.php';
$all=getPatients(); $sel=(int)($_GET['p']??0);
// تصنيف أثر الوجبة يأتي من الـ backend (SR17.2): moderate أو high
$IMP=['moderate'=>'ctrl','high'=>'crit'];
$meals=[];
foreach($all as $id=>$p){ if($sel && $sel!==$id) continue;
  foreach($p['meals'] as $m){ $m['pt']=$p['name']; $m['pid']=$id; $m['d']=$m['after']-$m['before']; $meals[]=$m; } }
usort($meals, fn($a,$b)=>$b['at']<=>$a['at']);
$n=count($meals);
$avgC=$n?round(array_sum(array_column($meals,'carbs'))/$n):null;
$avgD=$n?round(array_sum(array_column($meals,'d'))/$n):null;
$hi=count(array_filter($meals,fn($m)=>($m['imp']??'')==='high'));
?>
  <div class="bar"><h2><?= tt('meals.count',['n'=>$n]) ?></h2>
    <form method="get"><select name="p" onchange="this.form.submit()" aria-label="<?= tt('common.select_patient') ?>">
      <option value="0"><?= tt('common.all_patients') ?></option>
      <?php foreach($all as $id=>$p): ?><option value="<?= $id ?>" <?= $sel===$id?'selected':'' ?>><?= h($p['name']) ?></option><?php endforeach; ?>
    </select></form></div>
  <section class="stats">
    <div class="card c-info"><div class="ico"><?= ic('meal') ?></div><div><small><?= tt('meals.card.n') ?></small><b><?= $n ?></b></div></div>
    <div class="card c-avg"><div class="ico"><?= ic('meal') ?></div><div><small><?= tt('meals.card.carbs') ?></small><b><?= $avgC===null?'—':$avgC.' <span>'.tt('unit.g').'</span>' ?></b></div></div>
    <div class="card c-ctrl"><div class="ico"><?= ic('trend') ?></div><div><small><?= tt('meals.card.rise') ?></small><b><?= $avgD===null?'—':ltr(sprintf('%+d',$avgD)).' <span>'.tt('unit.mgdl').'</span>' ?></b></div></div>
    <div class="card c-high"><div class="ico"><?= ic('alert') ?></div><div><small><?= tt('meals.card.hi') ?></small><b><?= $hi ?></b></div></div>
  </section>
  <h2 class="sub"><?= tt('meals.list') ?></h2>
  <?php if(!$meals) echo '<p class="empty">'.tt('meals.none').'</p>'; ?>
  <section class="mgrid">
  <?php foreach($meals as $m): $im=$IMP[$m['imp']??''] ?? null; ?>
    <article class="meal <?= $im ?? 'ok' ?>" data-s="<?= h(mb_strtolower($m['name'].' '.$m['pt'].' '.implode(' ',$m['items']))) ?>">
      <div class="mtop"><div class="ico"><?= ic('meal') ?></div>
        <div><b dir="auto"><?= h($m['name']) ?></b><small><a href="patient.php?id=<?= $m['pid'] ?>#t-ml"><?= h($m['pt']) ?></a> · <?= h(tv('mealtype.',$m['type'])) ?> · <?= h(ldate('M d · h:i A',$m['at'])) ?></small></div>
        <?= $im ? '<span class="pill b-'.$im.'">'.tt('imp.'.$m['imp']).'</span>' : '<span class="pill b-none">'.tt('imp.none').'</span>' ?></div>
      <div class="chips"><span><b><?= h($m['carbs']) ?> <?= tt('unit.g') ?></b> <?= tt('meals.carbs') ?></span><span><b><?= h($m['protein']) ?> <?= tt('unit.g') ?></b> <?= tt('meals.protein') ?></span><span><b><?= h($m['fat']) ?> <?= tt('unit.g') ?></b> <?= tt('meals.fat') ?></span><span><b><?= h($m['kcal']) ?></b> <?= tt('meals.kcal') ?></span></div>
      <div class="gl"><span><?= h($m['before']) ?></span> → <span><?= h($m['after']) ?></span> <em><?= tt('unit.mgdl') ?></em> <strong><?= sprintf('%+d',$m['d']) ?></strong></div>
      <div class="tags"><?php foreach($m['items'] as $i) echo '<span dir="auto">'.h($i).'</span>'; ?></div>
    </article>
  <?php endforeach; ?>
  </section>
<?php require __DIR__.'/footer.php'; ?>

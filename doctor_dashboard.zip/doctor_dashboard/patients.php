<?php
require_once __DIR__.'/data.php';
$page='patients'; $title=t('nav.patients'); $heading=t('pats.heading'); $sub=t('pats.sub');
require __DIR__.'/header.php';
$order=['crit'=>0,'high'=>1,'low'=>1,'ctrl'=>2,'ok'=>3];
// المرضى بدون تصنيف يظهرون في الآخر
$ps=getPatients(); uasort($ps, fn($a,$b)=>($order[$a['status']??'']??9)<=>($order[$b['status']??'']??9));
?>
  <div class="bar"><h2><?= tt('pats.count',['n'=>count($ps)]) ?></h2>
    <select id="filter" aria-label="<?= tt('pats.filter') ?>"><option value=""><?= tt('pats.all_status') ?></option>
      <?php foreach (['ok','ctrl','crit'] as $k): ?><option value="<?= $k ?>"><?= h(PST[$k]) ?></option><?php endforeach; ?>
    </select></div>
  <div class="list">
  <?php foreach ($ps as $p): $l=$p['readings'][0] ?? null; ?>
    <a class="row pl <?= $p['status'] ?? 'none' ?>" href="patient.php?id=<?= $p['id'] ?>" data-st="<?= $p['status'] ?>" data-s="<?= h(mb_strtolower($p['name'].' '.patientMeta($p).' '.($p['status']?PST[$p['status']]:''))) ?>">
      <div class="who"><div class="avatar"><?= h(initials($p['name'])) ?></div><div><b dir="auto"><?= h($p['name']) ?></b><small><?= h(patientMeta($p)) ?></small></div></div>
      <?php if($l): ?><div class="val"><b><?= h($l['v']) ?></b> <span><?= tt('unit.mgdl') ?></span><div class="when"><?= tt('pats.last',['when'=>ldate('M d · h:i A',$l['at'])]) ?></div></div>
      <?php else: ?><div class="val"><b>—</b><div class="when"><?= tt('pats.no_readings') ?></div></div><?php endif; ?>
      <div class="stat"><?= statusPill($p['status']) ?></div>
      <span><?= tt('common.chev') ?></span></a>
  <?php endforeach; ?>
  </div>
  <script>document.getElementById('filter').onchange=e=>document.querySelectorAll('[data-st]').forEach(r=>r.style.display=!e.target.value||r.dataset.st===e.target.value?'':'none')</script>
<?php require __DIR__.'/footer.php'; ?>

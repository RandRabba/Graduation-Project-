<?php
require_once __DIR__.'/data.php';
$d=getDoctor(); $err=''; $perr=''; $tab='t-info'; $editing=false;
// الرسائل تُحفظ كمفاتيح ترجمة حتى تظهر بلغة الصفحة بعد إعادة التحميل
$flash=$_SESSION['flash']??''; unset($_SESSION['flash']);
$done=function($key,$tab){ $_SESSION['flash']=$key; header("Location: profile.php#$tab"); exit; };
if($_SERVER['REQUEST_METHOD']==='POST'){
  $act=$_POST['act']??'';
  // ملف أكبر من post_max_size يصل بدون أي حقول
  if(!$_POST && (int)($_SERVER['CONTENT_LENGTH']??0)>0) $perr='prof.msg.photo_size';
  if($act==='photo'){
    $f=$_FILES['photo']??null; $MIME=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if(!$f || $f['error']===UPLOAD_ERR_NO_FILE) $perr='prof.msg.photo_choose';
    elseif(in_array($f['error'],[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE]) || $f['size']>2*1024*1024) $perr='prof.msg.photo_size';
    elseif($f['error']!==UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) $perr='prof.msg.photo_upload';
    elseif(!isset($MIME[$mime=(@getimagesize($f['tmp_name'])['mime'] ?? '')])) $perr='prof.msg.photo_type';
    else{
      // الامتداد يُحدد من نوع الصورة الفعلي وليس من اسم الملف
      if(!is_dir(__DIR__.'/uploads')) mkdir(__DIR__.'/uploads');
      foreach(glob(__DIR__.'/uploads/doctor.*') ?: [] as $o) unlink($o);
      if(move_uploaded_file($f['tmp_name'], __DIR__.'/uploads/doctor.'.$MIME[$mime])) $done('prof.msg.photo_ok','t-info');
      $perr='prof.msg.photo_save';
    }
  }
  if($act==='nophoto'){
    foreach(glob(__DIR__.'/uploads/doctor.*') ?: [] as $o) unlink($o);
    $done('prof.msg.photo_removed','t-info');
  }
  if($act==='info'){
    $tab='t-info';
    $in=[]; foreach(['name','spec','hosp','email','phone','loc'] as $k) $in[$k]=trim($_POST[$k]??'');
    if(in_array('',$in,true)){ $err='prof.msg.fields'; }
    elseif(!filter_var($in['email'],FILTER_VALIDATE_EMAIL)){ $err='prof.msg.email'; }
    else{ $_SESSION['doc']=$in+($_SESSION['doc']??[]); $done('prof.msg.updated','t-info'); }
    $d=$in+$d; $editing=true;
  }
  if($act==='pw'){
    $tab='t-sec';
    // لا توجد كلمة مرور حقيقية قبل ربط تسجيل الدخول بالـ backend، لذلك لا نتحقق من كلمة وهمية
    $hash=$_SESSION['doc']['pw'] ?? null;
    $new=$_POST['new']??'';
    if(!$hash) $err='prof.msg.pw_na';
    elseif(!password_verify($_POST['cur']??'',$hash)) $err='prof.msg.pw_cur';
    elseif(strlen($new)<8 || !preg_match('/[A-Z]/',$new) || !preg_match('/\d/',$new)) $err='prof.msg.pw_rule';
    elseif($new!==($_POST['conf']??'')) $err='prof.msg.pw_match';
    else{ $_SESSION['doc']['pw']=password_hash($new,PASSWORD_DEFAULT); $done('prof.msg.pw_ok','t-sec'); }
  }
  if($act==='notif'){
    $_SESSION['doc']['notif']=array_map(fn($k)=>(int)isset($_POST[$k]), ['crit'=>'crit','msg'=>'msg','rem'=>'rem','email'=>'email']);
    $done('prof.msg.notif_ok','t-not');
  }
  if($act==='prefs'){
    // اللغة والمظهر يُطبَّقان فوراً من أزرارهما، وهذا النموذج يحفظ وحدة السكر فقط
    $_SESSION['doc']['unit']=in_array($_POST['unit']??'',['mg/dL','mmol/L'],true)?$_POST['unit']:'mg/dL';
    $done('prof.msg.prefs_ok','t-pref');
  }
}
$page='profile'; $title=t('nav.profile'); $heading=t('nav.profile'); $sub=t('prof.sub');
require __DIR__.'/header.php';
$F=[['name','text'],['spec','text'],['hosp','text'],['email','email'],['phone','tel'],['loc','text']];
$TABS=['t-info'=>'prof.tab.info','t-sec'=>'prof.tab.sec','t-not'=>'prof.tab.not','t-pref'=>'prof.tab.pref'];
?>
  <section class="pro">
    <form method="post" enctype="multipart/form-data" class="pav">
      <input type="hidden" name="act" value="photo">
      <?= docAvatar($d,'avatar xl') ?>
      <label class="cam" title="<?= tt('prof.change_photo') ?>"><?= ic('camera') ?><input type="file" name="photo" accept="image/jpeg,image/png,image/webp" aria-label="<?= tt('prof.change_photo') ?>" onchange="this.form.submit()"></label>
    </form>
    <div class="pinfo">
      <h2><span dir="auto"><?= h($d['name']) ?></span> <button type="button" class="pen js-edit" aria-label="<?= tt('prof.edit') ?>"><?= ic('pencil') ?></button></h2>
      <p dir="auto"><?= $d['spec']!==''?h($d['spec']):tt('prof.spec_unset') ?></p>
      <?php $meta=array_filter(['building'=>$d['hosp'],'pin'=>$d['loc'],'mail'=>$d['email']], fn($v)=>$v!==''); ?>
      <div class="pmeta"><?php foreach($meta as $i=>$v) echo '<span>'.ic($i).'<bdi>'.h($v).'</bdi></span>'; if(!$meta) echo '<span class="hint">'.tt('prof.meta_unset').'</span>'; ?></div>
      <?php if(docPhoto()): ?><form method="post" class="nophoto"><input type="hidden" name="act" value="nophoto"><button class="lnk del"><?= tt('prof.remove_photo') ?></button></form><?php endif; ?>
      <?php if($perr): ?><p class="warn"><?= tt($perr) ?></p><?php endif; ?>
    </div>
    <button type="button" class="btn ghost js-edit"><?= ic('pencil') ?> <?= tt('prof.edit_btn') ?></button>
  </section>

  <section class="stats">
    <div class="card c-avg"><div class="ico"><?= ic('steth') ?></div><div><small><?= tt('prof.card.spec') ?></small><strong dir="auto"><?= $d['spec']!==''?h($d['spec']):'—' ?></strong></div></div>
    <div class="card c-ok"><div class="ico"><?= ic('users') ?></div><div><small><?= tt('prof.card.pats') ?></small><b><?= count(getPatients()) ?></b></div></div>
    <div class="card c-high"><div class="ico"><?= ic('calendar') ?></div><div><small><?= tt('prof.card.joined') ?></small><b><?= $d['joined'] ? h(ldate('M Y',$d['joined'])) : '—' ?></b></div></div>
    <div class="card c-ok"><div class="ico"><?= ic('shield') ?></div><div><small><?= tt('prof.card.status') ?></small><?= $d['status'] ? '<span class="pill on">'.h(tv('acct.',$d['status'])).'</span>' : '<b>—</b>' ?></div></div>
  </section>

  <?php if($flash): ?><p class="okmsg"><?= tt($flash) ?></p><?php endif; ?>
  <div class="tabs pills">
    <?php foreach($TABS as $k=>$v): ?><button data-tab="<?= $k ?>" class="<?= $k===$tab?'on':'' ?>"><?= tt($v) ?></button><?php endforeach; ?>
  </div>

  <section class="tab" id="t-info" <?= $tab==='t-info'?'':'hidden' ?>>
    <form method="post" class="pform <?= $editing?'editing':'' ?>" id="pinfo">
      <input type="hidden" name="act" value="info">
      <?php if($err && $tab==='t-info'): ?><p class="warn"><?= tt($err) ?></p><?php endif; ?>
      <?php foreach($F as [$k,$t]): ?>
        <label><?= tt('prof.f.'.$k) ?><input type="<?= $t ?>" name="<?= $k ?>" value="<?= h($d[$k]) ?>" dir="auto" placeholder="<?= tt('prof.not_set') ?>" required <?= $editing?'':'readonly' ?>></label>
      <?php endforeach; ?>
      <div class="pact"><button type="submit" class="btn"><?= tt('prof.save') ?></button><a class="btn ghost" href="profile.php"><?= tt('prof.cancel') ?></a></div>
    </form>
  </section>

  <section class="tab" id="t-sec" <?= $tab==='t-sec'?'':'hidden' ?>>
    <form method="post" class="pform editing">
      <input type="hidden" name="act" value="pw">
      <?php if($err && $tab==='t-sec'): ?><p class="warn"><?= tt($err) ?></p>
      <?php elseif(empty($_SESSION['doc']['pw'])): ?><p class="warn"><?= tt('prof.msg.pw_na') ?></p><?php endif; ?>
      <label><?= tt('prof.pw.cur') ?><input type="password" name="cur" required autocomplete="current-password"></label>
      <label><?= tt('prof.pw.new') ?><input type="password" name="new" required minlength="8" autocomplete="new-password"></label>
      <label><?= tt('prof.pw.conf') ?><input type="password" name="conf" required minlength="8" autocomplete="new-password"></label>
      <small class="hint"><?= tt('prof.pw.hint') ?></small>
      <div class="pact"><button type="submit" class="btn"><?= tt('prof.pw.btn') ?></button></div>
    </form>
  </section>

  <section class="tab" id="t-not" hidden>
    <form method="post" class="pform editing one">
      <input type="hidden" name="act" value="notif">
      <?php foreach(['crit','msg','rem','email'] as $k): ?>
        <label class="sw"><span><b><?= tt('prof.n.'.$k) ?></b><small><?= tt('prof.n.'.$k.'_d') ?></small></span><input type="checkbox" name="<?= $k ?>" <?= !empty($d['notif'][$k])?'checked':'' ?>><i></i></label>
      <?php endforeach; ?>
      <div class="pact"><button type="submit" class="btn"><?= tt('prof.n.save') ?></button></div>
    </form>
  </section>

  <section class="tab" id="t-pref" hidden>
    <form method="post" class="pform editing">
      <input type="hidden" name="act" value="prefs">
      <div class="pref"><span id="lbl-lang"><?= tt('prof.lang') ?></span>
        <!-- اختيار اللغة يعيد تحميل الصفحة باللغة الجديدة ويحفظها في cookie (data.php) -->
        <div class="seg" role="group" aria-labelledby="lbl-lang">
          <?php foreach(['en'=>'English','ar'=>'العربية'] as $l=>$name): ?><a href="<?= h(langUrl($l)) ?>#t-pref" lang="<?= $l ?>" class="<?= LANG===$l?'on':'' ?>" <?= LANG===$l?'aria-current="true"':'' ?>><?= $name ?></a><?php endforeach; ?>
        </div></div>
      <div class="pref"><span id="lbl-theme"><?= tt('prof.theme') ?></span>
        <div class="seg" role="group" aria-labelledby="lbl-theme" id="themeSeg"><button type="button" data-v="light"><?= tt('prof.light') ?></button><button type="button" data-v="dark"><?= tt('prof.dark') ?></button></div></div>
      <!-- وحدة السكر تُحفظ مباشرة عند تغييرها، مثل اللغة والمظهر -->
      <label><?= tt('prof.unit') ?><select name="unit" onchange="this.form.submit()"><?php foreach(['mg/dL','mmol/L'] as $u): ?><option <?= $d['unit']===$u?'selected':'' ?>><?= $u ?></option><?php endforeach; ?></select></label>
    </form>
  </section>

  <script>
    // زر التعديل يفتح الحقول للكتابة
    document.querySelectorAll('.js-edit').forEach(b=>b.onclick=()=>{
      document.querySelector('.tabs button[data-tab="t-info"]').click();
      const f=document.getElementById('pinfo'); f.classList.add('editing');
      f.querySelectorAll('input[readonly]').forEach(i=>i.readOnly=false); f.querySelector('input[name=name]').focus();
    });
    // المظهر يتغير فوراً ويُحفظ (setTheme في Common.js)
    const seg=document.querySelectorAll('#themeSeg button'), mark=()=>seg.forEach(x=>{const on=x.dataset.v===document.documentElement.dataset.theme; x.classList.toggle('on',on); x.setAttribute('aria-pressed',on);});
    seg.forEach(b=>b.onclick=()=>{ setTheme(b.dataset.v); mark(); });
    mark();
  </script>
<?php require __DIR__.'/footer.php'; ?>

<?php
require_once __DIR__.'/data.php';
$all=getPatients(); $sel=(int)($_GET['p']??0); $err='';
$old=['pid'=>$sel,'type'=>'med','title'=>'','at'=>'','rep'=>'once'];
$back='reminders.php'.($sel?'?p='.$sel:'');
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['del'])){
    // الطبيبة تحذف فقط التذكيرات التي أنشأتها هي
    foreach(getReminders() as $r) if($r['id']===$_POST['del'] && $r['src']==='doctor') $_SESSION['remdel'][]=$r['id'];
    header("Location: $back"); exit;
  }
  $old=['pid'=>(int)($_POST['pid']??0),'type'=>$_POST['type']??'','title'=>trim($_POST['title']??''),'at'=>$_POST['at']??'','rep'=>$_POST['rep']??''];
  $ts=strtotime($old['at']);
  if(!isset($all[$old['pid']]) || !array_key_exists($old['type'],RTYPE) || !array_key_exists($old['rep'],RREP) || $old['title']==='' || !$ts) $err='rem.err_fields';
  elseif($ts<=time()) $err='rem.err_past';
  else{
    $_SESSION['rem'][]=['id'=>uniqid('r'),'pid'=>$old['pid'],'type'=>$old['type'],'title'=>$old['title'],'at'=>$ts,'rep'=>$old['rep'],'src'=>'doctor','st'=>'up'];
    header("Location: $back"); exit;
  }
}
$page='reminders'; $title=t('nav.reminders'); $heading=t('nav.reminders'); $sub=t('rem.sub');
require __DIR__.'/header.php';
$items=array_values(array_filter(getReminders(), fn($r)=>!$sel || $r['pid']===$sel));
$cnt=fn($st)=>count(array_filter($items,fn($r)=>$r['st']===$st));
$nToday=count(array_filter($items,fn($r)=>$r['st']==='up' && date('Y-m-d',$r['at'])===date('Y-m-d')));
$nWeek=count(array_filter($items,fn($r)=>$r['st']==='up' && $r['at']<strtotime('+7 days')));
$nDone=$cnt('done'); $nMiss=$cnt('missed');
$adh=$nDone+$nMiss ? round($nDone/($nDone+$nMiss)*100).'%' : '—';
?>
  <div class="bar"><h2><?= t('rem.count',['n'=>'<span id="cnt">'.count($items).'</span>']) ?></h2>
    <div class="ctl">
      <div class="seg" role="group" aria-label="<?= tt('rem.filter') ?>">
        <button data-f="all" class="on"><?= tt('common.all') ?></button><?php foreach(RST as $k=>$v): ?><button data-f="<?= $k ?>"><?= h($v) ?></button><?php endforeach; ?>
      </div>
      <form method="get"><select name="p" onchange="this.form.submit()" aria-label="<?= tt('common.select_patient') ?>">
        <option value="0"><?= tt('common.all_patients') ?></option>
        <?php foreach($all as $k=>$x): ?><option value="<?= $k ?>" <?= $sel===$k?'selected':'' ?>><?= h($x['name']) ?></option><?php endforeach; ?>
      </select></form></div></div>

  <section class="stats">
    <div class="card c-avg"><div class="ico"><?= ic('calendar') ?></div><div><small><?= tt('rem.card.today') ?></small><b><?= $nToday ?></b></div></div>
    <div class="card c-info"><div class="ico"><?= ic('clock') ?></div><div><small><?= tt('rem.card.week') ?></small><b><?= $nWeek ?></b></div></div>
    <div class="card c-high"><div class="ico"><?= ic('xcircle') ?></div><div><small><?= tt('rem.card.missed') ?></small><b><?= $nMiss ?></b></div></div>
    <div class="card c-ok"><div class="ico"><?= ic('check') ?></div><div><small><?= tt('rem.card.adh') ?></small><b><?= $adh ?></b></div></div>
  </section>

  <h2 class="sub" id="new"><?= tt('rem.new') ?></h2>
  <form method="post" class="rform">
    <?php if($err): ?><p class="warn"><?= tt($err) ?></p><?php endif; ?>
    <label><?= tt('rem.patient') ?><select name="pid" required>
      <option value=""><?= tt('rem.choose') ?></option>
      <?php foreach($all as $k=>$x): ?><option value="<?= $k ?>" <?= $old['pid']===$k?'selected':'' ?>><?= h($x['name']) ?></option><?php endforeach; ?>
    </select></label>
    <label><?= tt('rem.type') ?><select name="type">
      <?php foreach(RTYPE as $k=>$x): ?><option value="<?= $k ?>" <?= $old['type']===$k?'selected':'' ?>><?= h($x[1]) ?></option><?php endforeach; ?>
    </select></label>
    <label class="wide"><?= tt('rem.title') ?><input name="title" dir="auto" required maxlength="120" value="<?= h($old['title']) ?>" placeholder="<?= tt('rem.title_ph') ?>"></label>
    <label><?= tt('rem.at') ?><input type="datetime-local" name="at" required min="<?= date('Y-m-d\TH:i') ?>" value="<?= h($old['at']) ?>"></label>
    <label><?= tt('rem.repeat') ?><select name="rep">
      <?php foreach(RREP as $k=>$x): ?><option value="<?= $k ?>" <?= $old['rep']===$k?'selected':'' ?>><?= h($x) ?></option><?php endforeach; ?>
    </select></label>
    <button type="submit" class="btn"><?= tt('rem.add') ?></button>
  </form>

  <h2 class="sub"><?= tt('rem.list') ?></h2>
  <section class="list" id="rl">
    <?php foreach($items as $r){
      $act=$r['src']==='doctor' ? '<form method="post"><input type="hidden" name="del" value="'.h($r['id']).'"><button class="lnk del">'.tt('rem.delete').'</button></form>' : '';
      echo remRow($r, $all[$r['pid']]['name'], $act ?: '<small>'.tt('rem.view_only').'</small>');
    } if(!$items) echo '<p class="empty">'.tt('rem.none').'</p>'; ?>
  </section>
  <script>
    document.querySelectorAll('.seg button').forEach(b=>b.onclick=()=>{
      document.querySelectorAll('.seg button').forEach(x=>x.classList.toggle('on',x===b));
      let c=0; document.querySelectorAll('#rl [data-t]').forEach(r=>{const ok=b.dataset.f==='all'||r.dataset.t===b.dataset.f; r.style.display=ok?'':'none'; if(ok)c++});
      document.getElementById('cnt').textContent=c;
    });
  </script>
<?php require __DIR__.'/footer.php'; ?>

<?php
// ===== بيانات اختبار مؤقتة (TEST DATA ONLY) =====
// ليست بيانات مرضى حقيقية. تُستخدم فقط لتجربة شكل النظام ووظائفه قبل ربط الـ backend.
// data.php يقرأ هذا الملف إن وُجد، وتظهر رسالة "وضع الاختبار" أعلى كل صفحة.
// للتعطيل/الحذف: احذف هذا الملف فقط، وستعود كل الصفحات إلى البيانات الحقيقية (الفارغة حالياً).
//
// كل شيء مترابط ومبني من مصدر واحد:
// - قراءات السكر تحدد التصنيف والإحصائيات، والتنبيهات تُشتق من القراءات غير الطبيعية
// - لكل وجبة قراءة بعد الأكل (PPBS) بنفس القيمة
// - التقرير الأول يُنشأ تلقائياً في data.php بعد 14 يوماً من أول قراءة (رند 20 يوماً، ريهام 16، المريض الثالث 10 فلا تقرير بعد)
// - الأوقات نسبية لبداية اليوم الحالي حتى تبقى البيانات حديثة وثابتة خلال اليوم

$D = 86400; $t0 = strtotime('today'); $now = time();
$at = fn(int $day, float $hour) => (int)($t0 + $day * $D + $hour * 3600);   // $day سالب = أيام مضت
// التصنيف لا يُكتب هنا: data.php يصنف كل قراءة حسب أهداف المريض (classify) حتى يبقى موحداً في كل الصفحات

// النوع والعلاج والأهداف الفردية. المريض الثالث كبير في السن على أدوية فموية، فأهدافه حسب التوافق الدولي
// لكبار السن/الخطورة العالية: الوقت ضمن النطاق >50%، أقل من النطاق <1%، أعلى من 250 <10%
$patients = [
  // الحالة العامة (طبيعي/مضبوط/حرج) لا تُكتب هنا؛ data.php يحسبها من القراءات (overallStatus)
  1 => ['age'=>28, 'type'=>'Type 1', 'treat'=>'insulin', 'cg'=>'Sample caregiver · 000-000-0001'],
  2 => ['age'=>34, 'type'=>'Type 2', 'treat'=>'oral', 'cg'=>'Sample caregiver · 000-000-0002'],
  3 => ['name'=>'Sample Patient', 'age'=>72, 'type'=>'Type 2', 'treat'=>'oral', 'targets'=>['tir'=>50, 'tbr'=>1, 'tar2'=>10],
        'cg'=>null],
];

// [أيام البيانات، المتوسط، مدى التذبذب، بذرة ثابتة، قراءات منخفضة مضافة، آخر قراءة (تحدد الحالة الحالية)]
$plan = [
  1 => [20, 178, 62, 11, [[-12, 3.2, 62], [-4, 4.1, 58]], 268],
  2 => [16, 158, 44, 22, [[-9, 4.5, 66]], 212],
  3 => [10, 116, 22, 33, [], 108],
];

$meals = [
  1 => [[-1, 13, 'Grilled chicken with rice', 'lunch', 62, 540, 38, 14, ['Grilled chicken', 'White rice', 'Green salad'], 148, 231, 'high'],
        [-3, 8, 'Oat bowl with banana', 'breakfast', 48, 310, 9, 6, ['Oats', 'Banana', 'Milk'], 132, 190, 'moderate'],
        [-8, 20, 'Pasta with tomato sauce', 'dinner', 78, 610, 18, 16, ['Pasta', 'Tomato sauce', 'Parmesan'], 155, 262, 'high']],
  2 => [[-2, 13, 'Lentil soup with bread', 'lunch', 45, 380, 20, 8, ['Lentils', 'Carrot', 'Bread'], 128, 176, 'moderate'],
        [-5, 20, 'Chicken shawarma wrap', 'dinner', 58, 620, 32, 24, ['Chicken', 'Flatbread', 'Garlic sauce'], 140, 214, 'high']],
  3 => [[-1, 8, 'Greek yogurt with berries', 'breakfast', 22, 210, 15, 5, ['Greek yogurt', 'Berries', 'Walnuts'], 98, 128, 'moderate'],
        [-4, 13, 'Grilled fish with vegetables', 'lunch', 18, 420, 36, 16, ['Fish', 'Zucchini', 'Olive oil'], 104, 131, 'moderate']],
];

$readings = []; $mealOut = []; $alerts = [];
foreach ($plan as $id => [$days, $base, $amp, $seed, $lows, $last]) {
  mt_srand($seed); $r = [];
  for ($d = -$days; $d <= 0; $d++) {
    // حساس CGM كل 3 ساعات تقريباً + قراءة صيام يدوية صباحاً
    foreach ([0, 3, 6, 9, 12, 15, 18, 21] as $h) {
      $v = (int)round($base + $amp * sin(($h - 9) / 24 * 2 * M_PI) + mt_rand(-22, 22));
      $r[] = ['v'=>$v, 'at'=>$at($d, $h + mt_rand(0, 40) / 60), 'src'=>'cgm', 'type'=>'RBS'];
    }
    $r[] = ['v'=>(int)round($base - $amp * .45 + mt_rand(-12, 12)), 'at'=>$at($d, 7 + mt_rand(0, 30) / 60), 'src'=>'manual', 'type'=>'FBS'];
  }
  foreach ($lows as [$d, $h, $v]) $r[] = ['v'=>$v, 'at'=>$at($d, $h), 'src'=>'cgm', 'type'=>'RBS'];
  foreach ($meals[$id] as $m) {
    [$d, $h, $name, $type, $carbs, $kcal, $prot, $fat, $items, $before, $after, $imp] = $m;
    $mealOut[$id][] = ['name'=>$name, 'type'=>$type, 'carbs'=>$carbs, 'kcal'=>$kcal, 'protein'=>$prot, 'fat'=>$fat,
      'before'=>$before, 'after'=>$after, 'items'=>$items, 'at'=>$at($d, $h), 'imp'=>$imp];
    $r[] = ['v'=>$after, 'at'=>$at($d, $h + 2), 'src'=>'manual', 'type'=>'PPBS'];
  }
  $r = array_values(array_filter($r, fn($x) => $x['at'] <= $now));
  usort($r, fn($a, $b) => $a['at'] <=> $b['at']);
  $r[count($r) - 1]['v'] = $last;                       // آخر قراءة = الحالة الحالية للمريض
  $readings[$id] = $r;
  // التنبيهات بنفس قاعدة data.php (تراعي النوع والعلاج): الحرجة والمنخفضة آخر 10 أيام، وفوق النطاق لمستخدمي الإنسولين آخر 24 ساعة
  $alerts[$id] = deriveAlerts($r, $patients[$id], $at(-10, 0));
}

$lastAt = fn(int $id) => end($readings[$id])['at'];
return [
  'patients' => $patients,
  'readings' => $readings,
  'meals'    => $mealOut,
  'alerts'   => $alerts,
  // تعليمات طبية سابقة: [النص، الوقت]
  'ins' => [
    1 => [['Recheck manually after any reading above 250 mg/dL and message me the result.', $at(-1, 10)],
          ['Check glucose every 4 hours and reduce carbs at dinner.', $at(-10, 9)]],
    2 => [['Walk for 15 minutes after dinner and limit bread at lunch.', $at(-6, 11)]],
  ],
  // المحادثات: [المرسل، النص، الوقت]
  'chat' => [
    1 => [['patient', 'Hi doctor, my sensor showed a high reading and I feel a bit dizzy.', $lastAt(1) + 300],
          ['doctor', 'Please drink water and check your glucose manually in 15 minutes, then tell me the number.', $lastAt(1) + 900],
          ['patient', 'The manual reading is still high. Should I take a correction dose?', $lastAt(1) + 2100]],
    2 => [['doctor', 'How were your readings after dinner this week?', $at(-5, 21)],
          ['patient', 'A bit high after the shawarma wrap, around 214.', $at(-5, 22.5)],
          ['doctor', 'Try a smaller portion and walk for 15 minutes after dinner.', $at(-5, 23)]],
    3 => [['patient', 'My readings look stable this week.', $at(-2, 18)],
          ['doctor', 'Great work. Keep the same routine and meals.', $at(-2, 19)]],
  ],
  // التذكيرات بنفس شكل تذكيرات الجلسة في data.php
  'reminders' => [
    ['id'=>'s1', 'pid'=>1, 'type'=>'glu', 'title'=>'Check glucose every 4 hours', 'at'=>$at(1, 8), 'rep'=>'daily', 'src'=>'doctor', 'st'=>'up'],
    ['id'=>'s2', 'pid'=>1, 'type'=>'med', 'title'=>'Long-acting insulin', 'at'=>$at(-1, 22), 'rep'=>'daily', 'src'=>'patient', 'st'=>'missed'],
    ['id'=>'s3', 'pid'=>1, 'type'=>'med', 'title'=>'Rapid-acting insulin before dinner', 'at'=>$at(1, 19), 'rep'=>'daily', 'src'=>'patient', 'st'=>'up'],
    ['id'=>'s4', 'pid'=>1, 'type'=>'glu', 'title'=>'Recheck after critical reading', 'at'=>$at(-1, 11), 'rep'=>'once', 'src'=>'system', 'st'=>'done'],
    ['id'=>'s5', 'pid'=>2, 'type'=>'med', 'title'=>'Metformin 500 mg with breakfast', 'at'=>$at(0, 8), 'rep'=>'daily', 'src'=>'patient', 'st'=>'done'],
    ['id'=>'s6', 'pid'=>2, 'type'=>'glu', 'title'=>'Fasting glucose check', 'at'=>$at(0, 7), 'rep'=>'daily', 'src'=>'system', 'st'=>'missed'],
    ['id'=>'s7', 'pid'=>2, 'type'=>'custom', 'title'=>'Clinic follow-up visit', 'at'=>$at(5, 10), 'rep'=>'once', 'src'=>'doctor', 'st'=>'up'],
    ['id'=>'s8', 'pid'=>3, 'type'=>'meal', 'title'=>'Healthy afternoon snack', 'at'=>$at(1, 16), 'rep'=>'daily', 'src'=>'patient', 'st'=>'up'],
    ['id'=>'s9', 'pid'=>3, 'type'=>'med', 'title'=>'Metformin 500 mg with dinner', 'at'=>$at(-1, 20), 'rep'=>'daily', 'src'=>'patient', 'st'=>'done'],
  ],
];

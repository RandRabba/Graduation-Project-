<?php
require_once __DIR__.'/data.php';
$doc = getDoctor();
$open = openAlerts();
$missed = missedReminders();
$nav = [['dashboard','home','index.php'],['patients','users','patients.php'],['meals','meal','meals.php'],['glucose','drop','glucose.php'],['stats','trend','report.php'],['reports','report','health_reports.php',newReports()],['chat','chat','chat.php'],['reminders','bell','reminders.php',$missed],['alerts','alert','alerts.php',$open],['profile','user','profile.php']];
?>
<!DOCTYPE html>
<html lang="<?= LANG ?>" dir="<?= DIR ?>" data-theme="light"<?= SAMPLE ? ' data-mode="test"' : '' ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DMS · <?= h($title) ?></title>
<link rel="stylesheet" href="style.css">
<script>document.documentElement.dataset.theme=localStorage.getItem('dms-theme')||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')</script>
<script>window.I18N=<?= json_encode(jsDict(), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP) ?>;window.ICONS=<?= json_encode(array_map('ic', array_combine($k=['drop','clock','alert','report'], $k)), JSON_HEX_AMP) ?>;</script>
</head>
<body>
<aside class="side" id="side">
  <div class="brand"><span class="logo"><?= ic('drop') ?></span><div><b>DMS</b><small><?= tt('app.full') ?></small></div></div>
  <nav>
    <?php foreach ($nav as $n): ?>
      <a href="<?= $n[2] ?>" class="<?= $n[0]===$page?'active':'' ?>"><?= ic($n[1]) ?><?= tt('nav.'.$n[0]) ?><?php if(!empty($n[3])): ?><em><?= $n[3] ?></em><?php endif; ?></a>
    <?php endforeach; ?>
  </nav>
  <p class="tag"><?= tt('app.tag1') ?><br><?= tt('app.tag2') ?></p>
</aside>
<div class="scrim" id="scrim" hidden></div>
<main>
  <header class="top">
    <button id="menu" class="icon menu" aria-label="<?= tt('top.menu') ?>" aria-controls="side" aria-expanded="false"><?= ic('menu') ?></button>
    <div class="hello"><div><h1 id="greet"<?= isset($greet) ? ' data-name="'.h($greet).'"' : '' ?>><?= h($heading) ?></h1><p><?= h($sub) ?></p></div></div>
    <input id="search" type="search" placeholder="<?= tt('top.search') ?>" aria-label="<?= tt('top.search') ?>">
    <a class="icon" href="reminders.php" aria-label="<?= $missed ? tt('top.rem_missed', ['n'=>$missed]) : tt('top.reminders') ?>" title="<?= tt('top.rem_title') ?>"><?= ic('bell') ?><?php if($missed): ?><i><?= $missed ?></i><?php endif; ?></a>
    <a class="user" href="profile.php" aria-label="<?= tt('top.profile') ?>"><?= docAvatar($doc) ?><div><b><?= h($doc['name']) ?></b><small><?= h($doc['spec']) ?></small></div></a>
  </header>

<?php
// طبقة البيانات: كل البيانات الطبية ستأتي من الـ backend (FastAPI). لا توجد بيانات تجريبية هنا
// الدوال ترجع قيماً فارغة إلى أن نربطها، والصفحات تعرض حالات فارغة
if (session_status() === PHP_SESSION_NONE) session_start();

// ===== اللغة =====
// الإنجليزية افتراضياً. الاختيار يُحفظ في cookie لمدة سنة حتى يبقى بعد إغلاق المتصفح
const LANGS = ['en', 'ar'];
function setLang(string $l): void {
  setcookie('dms-lang', $l, ['expires'=>time()+31536000, 'path'=>'/', 'samesite'=>'Lax']);
}
if (isset($_GET['lang']) && in_array($_GET['lang'], LANGS, true)) {
  setLang($_GET['lang']);
  $q = $_GET; unset($q['lang']);
  header('Location: '.basename($_SERVER['PHP_SELF']).($q ? '?'.http_build_query($q) : '')); exit;
}
define('LANG', in_array($_COOKIE['dms-lang'] ?? '', LANGS, true) ? $_COOKIE['dms-lang'] : 'en');
define('DIR', LANG === 'ar' ? 'rtl' : 'ltr');
// العربية تُكمل من الإنجليزية لأي مفتاح ناقص
$GLOBALS['I18N'] = LANG === 'en' ? require __DIR__.'/lang/en.php' : (require __DIR__.'/lang/'.LANG.'.php') + (require __DIR__.'/lang/en.php');
function t(string $k, array $a = []): string {
  $s = $GLOBALS['I18N'][$k] ?? $k;
  foreach ($a as $n => $v) $s = str_replace('{'.$n.'}', (string)$v, $s);
  return $s;
}
function tt(string $k, array $a = []): string { return h(t($k, $a)); }
// قيمة قادمة من الـ backend: نترجمها إن وُجد لها مفتاح، وإلا نعرضها كما هي
function tv(string $prefix, ?string $v): string { return $v !== null && isset($GLOBALS['I18N'][$prefix.$v]) ? $GLOBALS['I18N'][$prefix.$v] : (string)$v; }
function langUrl(string $l): string { return basename($_SERVER['PHP_SELF']).'?'.http_build_query(['lang'=>$l] + $_GET); }
function jsDict(): array {
  $k = ['card.avg','card.tir','card.high','card.low','card.total','empty.readings','js.nomatch','js.loaderr','dash.greet.morning','dash.greet.afternoon','dash.greet.evening','common.chev','unit.mgdl'];
  return array_combine($k, array_map('t', $k));
}
// التاريخ بأسماء الأشهر والأيام حسب اللغة. القيمة قد تكون timestamp أو نصاً قديماً محفوظاً في الجلسة
function ldate(string $f, $ts): string {
  if (!is_int($ts)) return (string)$ts;
  $s = date($f, $ts);
  if (LANG === 'en') return $s;
  static $map = null;
  if ($map === null) {
    $map = ['AM'=>t('time.am'), 'PM'=>t('time.pm')];
    foreach (['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $x) $map[$x] = t('cal.'.$x);
  }
  return strtr($s, $map);
}
// رقم بإشارة (+23) أو نطاق (70 – 180) يبقى بترتيبه الصحيح داخل نص عربي
function ltr($v): string { return '<bdi dir="ltr">'.h($v).'</bdi>'; }

// أيقونات خطية بسيطة (SVG) بدل الإيموجي. تأخذ لون النص المحيط بها
const ICONS = [
  'home'=>'<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/>',
  'users'=>'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8"/><path d="M18 14.2a6.5 6.5 0 0 1 3.5 5.8"/>',
  'meal'=>'<path d="M7 3v8"/><path d="M4 3v5a3 3 0 0 0 6 0V3"/><path d="M7 11v10"/><path d="M17 21V3c-2.2 1.2-3.5 3.6-3.5 6.5V14H17"/>',
  'drop'=>'<path d="M12 3s-6.5 7.2-6.5 11.5a6.5 6.5 0 0 0 13 0C18.5 10.2 12 3 12 3z"/>',
  'trend'=>'<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/>',
  'report'=>'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/>',
  'chat'=>'<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.6A8 8 0 1 1 21 12z"/>',
  'bell'=>'<path d="M6 9a6 6 0 0 1 12 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  'alert'=>'<path d="M10.3 4.2 2.6 17.5a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 4.2a2 2 0 0 0-3.4 0z"/><path d="M12 9.5v4M12 17h.01"/>',
  'user'=>'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  'pencil'=>'<path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/>',
  'camera'=>'<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
  'building'=>'<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M9 7h1M14 7h1M9 11h1M14 11h1M9 15h1M14 15h1M10 21v-3h4v3"/>',
  'pin'=>'<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  'mail'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  'clock'=>'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  'calendar'=>'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  'shield'=>'<path d="M12 3 5 6v5c0 4.5 3 8.3 7 10 4-1.7 7-5.5 7-10V6z"/>',
  'steth'=>'<path d="M6 3v5a4 4 0 0 0 8 0V3"/><path d="M10 12v2a5 5 0 0 0 10 0v-2"/><circle cx="20" cy="10" r="2"/>',
  'check'=>'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  'xcircle'=>'<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/>',
  'pill'=>'<rect x="3" y="8.5" width="18" height="7" rx="3.5" transform="rotate(-45 12 12)"/><path d="m9.5 9.5 5 5"/>',
  'activity'=>'<path d="M3 12h4l3-7 4 14 3-7h4"/>',
  'note'=>'<rect x="5" y="4" width="14" height="16" rx="2"/><path d="M9 9h6M9 13h6M9 17h3"/>',
  'swap'=>'<path d="m16 3 4 4-4 4"/><path d="M20 7H4"/><path d="m8 21-4-4 4-4"/><path d="M4 17h16"/>',
  'menu'=>'<path d="M4 7h16M4 12h16M4 17h16"/>',
];
function ic(string $n): string { return '<svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'.(ICONS[$n] ?? '').'</svg>'; }

define('PST', ['ok'=>t('st.ok'),'ctrl'=>t('st.ctrl'),'high'=>t('st.high'),'crit'=>t('st.crit'),'low'=>t('st.low')]);
// ===== أهداف السكر والتصنيف =====
// الأهداف الافتراضية من التوافق الدولي لمقاييس CGM (Battelino et al., Diabetes Care 2019) وتوصيات ADA:
// النطاق 70–180، المستوى 2 أقل من 54 أو أعلى من 250، الوقت ضمن النطاق >70%، أقل من النطاق <4% (أقل من 54 <1%)، أعلى من النطاق <25% (أعلى من 250 <5%)
// يمكن تخصيصها لكل مريض عبر 'targets' (مثلاً كبار السن/الخطورة العالية: ضمن النطاق >50%، أقل من النطاق <1%)
const DEFAULT_TG = ['low'=>70, 'high'=>180, 'vlow'=>54, 'vhigh'=>250, 'tir'=>70, 'tbr'=>4, 'tbr2'=>1, 'tar'=>25, 'tar2'=>5];
function targets(array $p): array { return array_replace(DEFAULT_TG, $p['targets'] ?? []); }
function insulinTreated(array $p): bool { return ($p['type'] ?? '') === 'Type 1' || ($p['treat'] ?? '') === 'insulin'; }
// التصنيف حسب أهداف المريض: حرج = المستوى 2 (أقل من 54 أو أعلى من 250)، منخفض = أقل من الحد الأدنى،
// طبيعي = ضمن النطاق، مضبوط = أعلى من النطاق دون المستوى الحرج
function classify(int $v, array $tg): string {
  if ($v < $tg['vlow'] || $v > $tg['vhigh']) return 'crit';
  if ($v < $tg['low']) return 'low';
  return $v <= $tg['high'] ? 'ok' : 'ctrl';
}
// نص النطاق الذي يظهر بجانب التصنيف، من أهداف المريض نفسه
function stRange(string $st, array $tg, ?int $v = null): string {
  return match ($st) {
    'ok' => $tg['low'].' – '.$tg['high'],
    'ctrl' => ($tg['high'] + 1).' – '.$tg['vhigh'],
    'low' => $tg['vlow'].' – '.($tg['low'] - 1),
    'crit' => ($v !== null && $v < $tg['low']) ? '< '.$tg['vlow'] : '> '.$tg['vhigh'],
    default => '> '.$tg['high'],
  };
}
// تنبيهات مشتقة من القراءات (لبيانات الاختبار؛ الـ backend سيرسل تنبيهاته). تراعي نوع السكري والعلاج:
// الحرجة والمنخفضة لكل المرضى، وفوق النطاق فقط لمن يستخدم الإنسولين (النوع الأول أو إنسولين) خلال آخر 24 ساعة
function deriveAlerts(array $rs, array $p, int $since): array {
  $tg = targets($p); $out = [];
  foreach ($rs as $x) {
    $st = $x['st'] ?? classify((int)$x['v'], $tg);
    if ((in_array($st, ['crit', 'low'], true) && $x['at'] >= $since) || ($st === 'ctrl' && insulinTreated($p) && $x['at'] >= time() - 86400))
      $out[] = ['st'=>$st, 'v'=>$x['v'], 'at'=>$x['at']];
  }
  usort($out, fn($a, $b) => $b['at'] <=> $a['at']);
  return $out;
}

// ===== وضع الاختبار =====
// بيانات اختبار مؤقتة (ليست بيانات حقيقية) تُحمّل فقط عند تحقق الشرطين معاً:
//   1) الملف sample_data.php موجود
//   2) البيئة ليست إنتاجية: متغير البيئة DMS_ENV لا يساوي "production"
// في الإنتاج اضبط DMS_ENV=production (مثلاً SetEnv في Apache) فلا تُحمّل حتى لو بقي الملف. ولإزالتها نهائياً احذف الملف.
// تدخل من نفس الأماكن التي سيأتي منها الـ backend: المرضى، القراءات، المحادثات، التذكيرات
// (تُحمّل بعد الأهداف والتصنيف لأنها تستخدمهما). لا يظهر أي مؤشر في الواجهة؛ فقط data-mode="test" على <html> للمطورين
define('APP_ENV', getenv('DMS_ENV') ?: 'development');
define('SAMPLE', APP_ENV !== 'production' && is_file(__DIR__.'/sample_data.php') ? require __DIR__.'/sample_data.php' : null);

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function initials($n){ $p=explode(' ',trim($n)); return strtoupper(substr($p[0],0,1).substr(end($p),0,1)); }

// المرضى: الأسماء فقط. باقي الحقول null أو [] إلى أن تصل من الـ backend
// age, type ('Type 1'|'Type 2'), treat ('insulin'|'oral'|'lifestyle'), targets (أهداف فردية، انظر DEFAULT_TG),
// status (مفتاح من PST), cg (المرافق). لا يوجد نظام اشتراكات: المتابعة والمراسلة متاحة لكل مريض مسند للطبيبة
// meals: ['name','type'=>'breakfast'|'lunch'|'dinner'|'snack','carbs','kcal','protein','fat','before','after','items'=>[],'at'=>timestamp,'imp'=>'moderate'|'high']
// alerts: ['st'=>'crit'|'high'|'ctrl'|'low','v'=>القيمة mg/dL,'at'=>timestamp] — العنوان يُبنى من الترجمة
// reports: ['id','kind'=>'first'|'weekly'|'monthly','from'=>timestamp,'to'=>timestamp,'at'=>وقت الإرسال] — العنوان يُبنى من الترجمة
function getPatients(): array {
  $p = [1 => ['id'=>1,'name'=>'Rand Rabba'], 2 => ['id'=>2,'name'=>'Riham']];
  if (SAMPLE) foreach (SAMPLE['patients'] as $id => $f) $p[$id] = array_replace(['id'=>$id], $p[$id] ?? [], $f);
  foreach ($p as $id => &$x) {
    $x += ['age'=>null,'type'=>null,'treat'=>null,'targets'=>null,'status'=>null,'cg'=>null,
      'meals'=>SAMPLE['meals'][$id] ?? [],'alerts'=>SAMPLE['alerts'][$id] ?? [],
      'ins'=>array_merge($_SESSION['ins'][$id] ?? [], SAMPLE['ins'][$id] ?? [])];
    $x['readings'] = getReadings($id, targets($x));
    // الحالة العامة: طبيعي/مضبوط/حرج فقط. تُحسب من بيانات المريض، وإن لم توجد قراءات نستخدم ما يرسله الـ backend
    // (مرتفع/منخفض ليست حالات للمريض، تُحسب "مضبوط")
    $x['status'] = overallStatus($x, $x['readings']) ?? (in_array($x['status'], ['high','low'], true) ? 'ctrl' : $x['status']);
    $x['reports'] = autoReports($x['readings']);
  }
  return $p;
}

// التقرير الصحي الأول: يُنشأ ويُرسل للطبيبة تلقائياً بعد 14 يوماً من أول قراءة سكر للمريض
// (نقطة البداية هي تاريخ أول قراءة، وليس تاريخ التسجيل). يحتوي فقط بيانات المريض المسجلة فعلاً خلال تلك الأيام
const FIRST_REPORT_DAYS = 14;
function autoReports(array $rs): array {
  if (!$rs) return [];
  $first = min(array_column($rs, 'at'));
  $due = $first + FIRST_REPORT_DAYS * 86400;
  return time() >= $due ? [['id'=>'first','kind'=>'first','from'=>$first,'to'=>$due,'at'=>$due]] : [];
}
// تقارير وصلت ولم تفتحها الطبيبة بعد (للعداد في القائمة الجانبية وشارة "جديد")
function reportSeen(int $pid, array $r): bool { return !empty($_SESSION['rep_seen'][$pid][$r['id']]); }
function newReports(): int {
  $n = 0;
  foreach (getPatients() as $id => $p) foreach ($p['reports'] as $r) if (!reportSeen($id, $r)) $n++;
  return $n;
}
function patientMeta(array $p): string {
  $a = [];
  if ($p['age'] !== null) $a[] = t('pat.years', ['n'=>$p['age']]);
  if ($p['type']) $a[] = tv('ptype.', $p['type']);
  if (!empty($p['treat'])) $a[] = tv('treat.', $p['treat']);
  return $a ? implode(' · ', $a) : t('pat.no_profile');
}
function statusPill(?string $st): string {
  return $st && array_key_exists($st, PST) ? '<span class="pill b-'.$st.'">'.h(PST[$st]).'</span>' : '<span class="pill b-none">'.tt('common.no_data').'</span>';
}
function dash($v, string $unit = ''): string { return $v === null ? '—' : $v.$unit; }
function alertTitle(array $a): string { return t('al.title.'.$a['st'], ['v'=>$a['v'] ?? '—']); }
function reportTitle(array $r): string { return t('rep.title.'.$r['kind']); }

// قراءات السكر التي سجلها المريض من تطبيق الجوال
// شكل القراءة: ['v'=>القيمة mg/dL, 'at'=>timestamp, 'src'=>'manual'|'cgm', 'type'=>'FBS'|'RBS'|'PPBS', 'st'=>التصنيف (اختياري)]
// تحليل الوجبات ليس مصدراً لقراءات السكر. إن أرسل الـ backend التصنيف يُستخدم كما هو، وإلا يُصنف هنا حسب أهداف المريض
define('GSRC', ['manual'=>[ic('drop'),t('src.manual')],'cgm'=>[ic('activity'),t('src.cgm')]]);
function getRecentReadings(int $id): array {
  return SAMPLE['readings'][$id] ?? [];
}
// القراءات الصالحة فقط، الأحدث أولاً
function getReadings(int $id, array $tg = DEFAULT_TG): array {
  $r = [];
  foreach (getRecentReadings($id) as $x) {
    if (!array_key_exists($x['src'] ?? '', GSRC)) continue;
    $x['st'] ??= classify((int)$x['v'], $tg);
    if (array_key_exists($x['st'], PST)) $r[] = $x;
  }
  usort($r, fn($a, $b) => $b['at'] <=> $a['at']);
  return $r;
}
// الإحصائيات: المتوسط من كل القراءات. الوقت ضمن النطاق وأعلى/أقل منه من قراءات الحساس (CGM) فقط،
// حسب أهداف المريض (التوافق الدولي). القراءات اليدوية متفرقة ولا تمثل الوقت، لذلك لا تدخل فيها
function glucoseStats(array $rs, array $tg = DEFAULT_TG): array {
  $n = count($rs);
  $cgm = array_column(array_filter($rs, fn($r) => $r['src'] === 'cgm'), 'v'); $c = count($cgm);
  $pct = fn(callable $f) => $c ? (int)round(count(array_filter($cgm, $f)) / $c * 100) : null;
  return ['avg'=>$n ? (int)round(array_sum(array_column($rs, 'v')) / $n) : null,
    'tir'=>$pct(fn($v) => $v >= $tg['low'] && $v <= $tg['high']),
    'high'=>$pct(fn($v) => $v > $tg['high']), 'low'=>$pct(fn($v) => $v < $tg['low']), 'total'=>$n, 'cgm'=>$c];
}
// توزيع الوقت على النطاقات الخمسة (من قراءات الحساس فقط) مع تحقق كل هدف
function tirBreakdown(array $rs, array $tg): ?array {
  $cgm = array_column(array_filter($rs, fn($r) => $r['src'] === 'cgm'), 'v'); $c = count($cgm);
  if (!$c) return null;
  $p = fn(callable $f) => count(array_filter($cgm, $f)) / $c * 100;
  $b = ['vlow'=>$p(fn($v) => $v < $tg['vlow']), 'low'=>$p(fn($v) => $v >= $tg['vlow'] && $v < $tg['low']),
    'in'=>$p(fn($v) => $v >= $tg['low'] && $v <= $tg['high']), 'high'=>$p(fn($v) => $v > $tg['high'] && $v <= $tg['vhigh']),
    'vhigh'=>$p(fn($v) => $v > $tg['vhigh'])];
  $met = ['vlow'=>$b['vlow'] < $tg['tbr2'], 'low'=>$b['vlow'] + $b['low'] < $tg['tbr'], 'in'=>$b['in'] > $tg['tir'],
    'high'=>$b['high'] + $b['vhigh'] < $tg['tar'], 'vhigh'=>$b['vhigh'] < $tg['tar2']];
  return ['pct'=>$b, 'met'=>$met, 'n'=>$c];
}
// الحالة العامة للمريض، واحدة فقط من ثلاث (طبيعي / مضبوط / حرج)، حسب أهدافه وآخر 14 يوماً (التوافق الدولي لـ CGM):
// حرج: آخر قراءة في المستوى 2 (أقل من 54 أو أعلى من 250)، أو تجاوز حد الوقت أقل من 54 / أقل من 70 / أعلى من 250
// مضبوط: ليس حرجاً لكن الوقت ضمن النطاق أقل من الهدف أو الوقت أعلى من 180 تجاوز حده
// طبيعي: كل الأهداف محققة. بدون بيانات حساس: حسب آخر قراءة (ضمن النطاق = طبيعي، غير ذلك = مضبوط)
function overallStatus(array $p, array $rs): ?string {
  if (!$rs) return null;
  if ($rs[0]['st'] === 'crit') return 'crit';
  $b = tirBreakdown(array_filter($rs, fn($r) => $r['at'] >= time() - 14 * 86400), targets($p));
  if (!$b) return $rs[0]['st'] === 'ok' ? 'ok' : 'ctrl';
  $m = $b['met'];
  if (!$m['vlow'] || !$m['low'] || !$m['vhigh']) return 'crit';
  return (!$m['in'] || !$m['high']) ? 'ctrl' : 'ok';
}
function dailyAverages(array $rs, int $days = 7, ?int $end = null): array {
  $end = strtotime('today', $end ?? time()); $out = [];
  for ($i = $days - 1; $i >= 0; $i--) {
    $d = strtotime("-$i days", $end);
    $v = array_column(array_filter($rs, fn($r) => $r['at'] >= $d && $r['at'] < $d + 86400), 'v');
    $out[] = [ldate($days > 7 ? 'M d' : 'D', $d), $v ? (int)round(array_sum($v) / count($v)) : null];
  }
  return $out;
}
// الرسم البياني يبقى من اليسار لليمين (محور الزمن) في اللغتين
function avgChart(array $series, string $label): string {
  $n = count($series); $step = $n > 1 ? 600 / ($n - 1) : 0; $pts = [];
  $o = '<svg class="chart" viewBox="0 0 700 200" role="img" aria-label="'.h($label).'"><rect x="0" y="'.(170-(180-60)/200*140).'" width="700" height="'.((180-70)/200*140).'" class="band"/>';
  foreach ($series as $i => [$day, $v]) {
    $x = round(50 + $i * $step, 1);
    if ($n <= 7 || $i % 5 === 0) $o .= '<text x="'.$x.'" y="195" text-anchor="middle" class="ax">'.h($day).'</text>';
    if ($v !== null) $pts[] = [$x, round(170 - (max(60, min(260, $v)) - 60) / 200 * 140, 1), $v];
  }
  if ($pts) {
    $o .= '<polyline class="line" points="'.implode(' ', array_map(fn($q) => $q[0].','.$q[1], $pts)).'"/>';
    foreach ($pts as $q) $o .= '<circle cx="'.$q[0].'" cy="'.$q[1].'" r="5" class="dot"/><text x="'.$q[0].'" y="'.($q[1]-12).'" text-anchor="middle">'.$q[2].'</text>';
  } else $o .= '<text x="350" y="60" text-anchor="middle" class="ax">'.tt('empty.readings').'</text>';
  return $o.'</svg>';
}
function readingRow(array $r, array $tg = DEFAULT_TG): string {
  $s = GSRC[$r['src']];
  return '<div class="row '.$r['st'].'" data-s="'.h(mb_strtolower($s[1].' '.($r['type'] ?? '').' '.$r['v'].' '.PST[$r['st']])).'"><div class="who"><div class="ico">'.$s[0].'</div><div><b>'.h($s[1]).'</b><small>'.h($r['type'] ?? '').'</small></div></div><div class="val"><b>'.h($r['v']).'</b> <span>'.tt('unit.mgdl').'</span><div class="when">'.h(ldate('M d, Y · h:i A', $r['at'])).'</div></div><div class="stat"><span class="pill">'.h(PST[$r['st']]).'</span><span class="rng">('.ltr(stRange($r['st'], $tg, (int)$r['v'])).')</span></div><span></span></div>';
}

// المحادثات: فقط الرسائل التي ترسلها الطبيبة، محفوظة في الجلسة إلى أن نربطها بالـ backend
function getChat(int $id): array {
  return array_merge(SAMPLE['chat'][$id] ?? [], $_SESSION['chat'][$id] ?? []);
}

// التذكيرات: فقط ما تضيفه الطبيبة (محفوظ في الجلسة) إلى أن تصل تذكيرات المرضى من الـ backend
define('RTYPE', ['med'=>[ic('pill'),t('rtype.med')],'glu'=>[ic('drop'),t('rtype.glu')],'meal'=>[ic('meal'),t('rtype.meal')],'custom'=>[ic('note'),t('rtype.custom')]]);
define('RREP', ['once'=>t('rrep.once'),'daily'=>t('rrep.daily'),'weekly'=>t('rrep.weekly')]);
define('RSRC', ['doctor'=>t('rsrc.doctor'),'patient'=>t('rsrc.patient'),'system'=>t('rsrc.system')]);
define('RST', ['up'=>t('rst.up'),'done'=>t('rst.done'),'missed'=>t('rst.missed')]);
const RCL = ['up'=>'info','done'=>'ok','missed'=>'high'];
function getReminders(): array {
  $del = $_SESSION['remdel'] ?? [];
  $r = array_values(array_filter(array_merge(SAMPLE['reminders'] ?? [], $_SESSION['rem'] ?? []), fn($x) => !in_array($x['id'], $del, true)));
  // تذكير لم يؤكده المريض بعد موعده يعتبر فائتاً
  foreach ($r as &$x) if ($x['st']==='up' && $x['at'] < time()) $x['st'] = 'missed';
  usort($r, fn($a, $b) => $a['at'] <=> $b['at']);
  return $r;
}
function remWhen(int $ts): string {
  $d = (int)round((strtotime(date('Y-m-d', $ts)) - strtotime('today')) / 86400);
  $day = [-1=>'day.yesterday',0=>'day.today',1=>'day.tomorrow'][$d] ?? null;
  return ($day ? t($day) : ldate('M d, Y', $ts)).' · '.ldate('h:i A', $ts);
}
function remRow(array $r, string $pt = '', string $act = ''): string {
  $meta = ($pt !== '' ? '<a href="patient.php?id='.$r['pid'].'#t-rm">'.h($pt).'</a> · ' : '').h(RTYPE[$r['type']][1].' · '.RREP[$r['rep']]);
  return '<div class="row '.RCL[$r['st']].'" data-t="'.$r['st'].'" data-s="'.h(mb_strtolower($r['title'].' '.$pt.' '.RTYPE[$r['type']][1].' '.RST[$r['st']])).'"><div class="who"><div class="ico">'.RTYPE[$r['type']][0].'</div><div><b dir="auto">'.h($r['title']).'</b><small>'.$meta.'</small></div></div><div class="val"><span>'.h(remWhen($r['at'])).'</span></div><div class="stat"><span class="pill">'.h(RST[$r['st']]).'</span><span class="rng">'.h(RSRC[$r['src']]).'</span></div>'.($act !== '' ? '<div class="act">'.$act.'</div>' : '<span></span>').'</div>';
}
function missedReminders(): int {
  return count(array_filter(getReminders(), fn($r) => $r['st']==='missed'));
}

// بيانات الطبيبة: الاسم فقط، والباقي تدخله الطبيبة من صفحة الملف الشخصي (محفوظ في الجلسة)
function getDoctor(): array {
  return ['lang'=>LANG] + ($_SESSION['doc'] ?? []) + ['name'=>'Dr. Roa Daraghmeh','spec'=>'','hosp'=>'','email'=>'','phone'=>'','loc'=>'',
    'joined'=>null,'status'=>null,'unit'=>'mg/dL','notif'=>['crit'=>1,'msg'=>1,'rem'=>1,'email'=>0]];
}
function docInitials(string $n): string { return initials(preg_replace('/^Dr\.?\s*/i', '', $n)); }
// صورة الطبيبة محفوظة في uploads/doctor.<ext>؛ إن لم توجد نعرض الأحرف الأولى
function docPhoto(): string {
  foreach (glob(__DIR__.'/uploads/doctor.*') ?: [] as $f) return 'uploads/'.basename($f).'?v='.filemtime($f);
  return '';
}
function docAvatar(array $d, string $cls = 'avatar'): string {
  $p = docPhoto();
  return $p ? '<img class="'.$cls.' pic" src="'.h($p).'" alt="'.h($d['name']).'">' : '<span class="'.$cls.'">'.h(docInitials($d['name'])).'</span>';
}

// عدد التنبيهات التي لم تراجعها الطبيبة بعد
function openAlerts(): int {
  $n = 0;
  foreach (getPatients() as $id => $p) foreach ($p['alerts'] as $i => $a) if (empty($_SESSION['ack'][$id][$i])) $n++;
  return $n;
}

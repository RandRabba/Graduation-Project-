<?php
require_once __DIR__.'/data.php';
$all=getPatients(); $id=(int)($_GET['id']??0);
if(!isset($all[$id])){ http_response_code(404); exit(tt('common.not_found')); }
// مراجعة التنبيه تتم من ملف المريض بعد الاطلاع على بياناته
$ai=isset($_GET['alert']) ? (int)$_GET['alert'] : null;
$alert=$ai!==null ? ($all[$id]['alerts'][$ai] ?? null) : null;
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['ack']) && $alert){
  $_SESSION['ack'][$id][$ai] = time();
  header('Location: alerts.php'.(!empty($_GET['p'])?'?p='.(int)$_GET['p']:'')); exit;
}
if($_SERVER['REQUEST_METHOD']==='POST' && trim($_POST['text']??'')!==''){
  $_SESSION["ins"][$id] ??= [];
  array_unshift($_SESSION['ins'][$id], [trim($_POST['text']), time()]);
  header("Location: patient.php?id=$id#t-ins"); exit;
}
$p=$all[$id]; $tg=targets($p); $s=glucoseStats($p['readings'],$tg);
$page='patients'; $title=$p['name']; $heading=$p['name']; $sub=t('file.sub',['meta'=>patientMeta($p)]);
require __DIR__.'/header.php';
$unit=' <span>'.tt('unit.mgdl').'</span>';
?>
  <div class="card c-info head">
    <div class="avatar big"><?= h(initials($p['name'])) ?></div>
    <div><b class="nm" dir="auto"><?= h($p['name']) ?></b><small><?= h(patientMeta($p)) ?></small>
    <small><?= tt('file.caregiver',['v'=>dash($p['cg'])]) ?></small></div>
    <?= statusPill($p['status']) ?>
  </div>
  <?php if($alert): $done=$_SESSION['ack'][$id][$ai]??null; $back='alerts.php'.(!empty($_GET['p'])?'?p='.(int)$_GET['p']:''); ?>
  <div class="row review <?= $alert['st'] ?>">
    <div class="who"><div class="ico"><?= ic('alert') ?></div><div><b><?= tt('file.reviewing',['t'=>alertTitle($alert)]) ?></b><small><?= h(ldate('M d, Y · h:i A',$alert['at'])) ?> · <?= tt('file.review_hint') ?></small></div></div>
    <div class="act">
      <a class="lnk" href="<?= h($back) ?>"><?= tt('file.back_alerts') ?></a>
      <?php if($done): ?><small><?= tt('file.reviewed',['d'=>ldate('M d · h:i A',$done)]) ?></small>
      <?php else: ?><form method="post"><button class="btn sm" name="ack" value="1"><?= tt('file.mark') ?></button></form><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
  <div class="tabs">
    <?php foreach(['t-ov'=>'tab.ov','t-rd'=>'tab.rd','t-ml'=>'tab.ml','t-al'=>'tab.al','t-rm'=>'tab.rm','t-rp'=>'tab.rp','t-ins'=>'tab.ins'] as $k=>$v): ?>
      <button data-tab="<?= $k ?>" class="<?= $k==='t-ov'?'on':'' ?>"><?= tt($v) ?></button><?php endforeach; ?>
  </div>

  <section class="tab" id="t-ov">
    <div class="stats">
      <div class="card c-avg"><div class="ico"><?= ic('drop') ?></div><div><small><?= tt('card.avg') ?></small><b><?= $s['avg']===null?'—':$s['avg'].$unit ?></b></div></div>
      <div class="card c-ok"><div class="ico"><?= ic('clock') ?></div><div><small><?= tt('card.tir') ?></small><b><?= dash($s['tir'],'%') ?></b></div></div>
      <div class="card c-ctrl"><div class="ico"><?= ic('alert') ?></div><div><small><?= tt('card.high') ?></small><b><?= dash($s['high'],'%') ?></b></div></div>
      <div class="card c-high"><div class="ico"><?= ic('drop') ?></div><div><small><?= tt('card.low') ?></small><b><?= dash($s['low'],'%') ?></b></div></div>
    </div>
    <h2 class="sub"><?= tt('file.daily7') ?></h2>
    <?= avgChart(dailyAverages($p['readings']), t('chart.daily')) ?>
    <small class="note"><?= tt('chart.band') ?></small>
  </section>

  <section class="tab list" id="t-rd" hidden>
    <?php foreach($p['readings'] as $r) echo readingRow($r,$tg); if(!$p['readings']) echo '<p class="empty">'.tt('empty.readings').'</p>'; ?>
  </section>

  <section class="tab list" id="t-ml" hidden>
    <?php foreach($p['meals'] as $m): ?>
      <div class="row ctrl" data-s="<?= h(mb_strtolower($m['name'])) ?>"><div class="who"><div class="ico"><?= ic('meal') ?></div><div><b dir="auto"><?= h($m['name']) ?></b><small><?= h(tv('mealtype.',$m['type'])) ?></small></div></div>
      <div class="val"><b><?= h($m['carbs']) ?> <?= tt('unit.g') ?></b> <span><?= tt('file.carbs') ?></span><div class="when"><?= h($m['kcal']) ?> <?= tt('file.kcal') ?></div></div>
      <div class="stat"><b><?= ltr($m['before'].' → '.$m['after']) ?></b> <span class="rng"><?= tt('file.before_after') ?></span></div><span></span></div>
    <?php endforeach; if(!$p['meals']) echo '<p class="empty">'.tt('file.no_meals').'</p>'; ?>
  </section>

  <section class="tab list" id="t-al" hidden>
    <?php foreach($p['alerts'] as $a): ?>
      <div class="row <?= $a['st'] ?>" data-s="<?= h(mb_strtolower(alertTitle($a))) ?>"><div class="who"><div class="ico"><?= ic('alert') ?></div><div><b><?= h(alertTitle($a)) ?></b><small><?= h(ldate('M d, Y · h:i A',$a['at'])) ?></small></div></div><span></span><span></span><span></span></div>
    <?php endforeach; if(!$p['alerts']) echo '<p class="empty">'.tt('file.no_alerts').'</p>'; ?>
  </section>

  <section class="tab list" id="t-rm" hidden>
    <a class="btn ghost" href="reminders.php?p=<?= $id ?>#new"><?= tt('file.set_rem') ?></a>
    <?php $rm=array_filter(getReminders(), fn($r)=>$r['pid']===$id);
    foreach($rm as $r) echo remRow($r); if(!$rm) echo '<p class="empty">'.tt('file.no_rem').'</p>'; ?>
  </section>

  <section class="tab list" id="t-rp" hidden>
    <?php foreach($p['reports'] as $i=>$r): ?>
      <a class="row pl ok" href="health_reports.php?p=<?= $id ?>&r=<?= $i ?>" data-s="<?= h(mb_strtolower(reportTitle($r))) ?>"><div class="who"><div class="ico"><?= ic('report') ?></div><div><b><?= h(reportTitle($r)) ?></b><small><?= h(ldate('M d, Y',$r['at'])) ?></small></div></div><span></span><span></span><span><?= tt('common.chev') ?></span></a>
    <?php endforeach; if(!$p['reports']) echo '<p class="empty">'.tt('file.no_reports').'</p>'; ?>
  </section>

  <section class="tab" id="t-ins" hidden>
    <form method="post" class="ins">
      <label for="text"><?= tt('ins.label',['name'=>$p['name']]) ?></label>
      <textarea id="text" name="text" rows="3" dir="auto" required placeholder="<?= tt('ins.ph') ?>"></textarea>
      <button type="submit" class="btn"><?= tt('ins.send') ?></button>
    </form>
    <h2 class="sub"><?= tt('ins.sent') ?></h2>
    <div class="list">
    <?php foreach($p['ins'] as $i): ?>
      <div class="row ok"><div class="who"><div class="ico"><?= ic('steth') ?></div><div><b dir="auto"><?= h($i[0]) ?></b><small><?= h(ldate('M d, Y · h:i A',$i[1])) ?></small></div></div><span></span><span></span><span></span></div>
    <?php endforeach; if(!$p['ins']) echo '<p class="empty">'.tt('ins.none').'</p>'; ?>
    </div>
  </section>
<?php require __DIR__.'/footer.php'; ?>

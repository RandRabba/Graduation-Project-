<?php
require_once __DIR__.'/data.php';
$all=getPatients(); $pid=(int)($_GET['p']??0); $ri=isset($_GET['r'])?(int)$_GET['r']:-1;
$view = $pid && isset($all[$pid]) && isset($all[$pid]['reports'][$ri]);
// فتح التقرير يعني أن الطبيبة استلمته؛ نسجله قبل الهيدر حتى يتحدث العداد فوراً
if($view) $_SESSION['rep_seen'][$pid][$all[$pid]['reports'][$ri]['id']] = time();
$page='reports'; $title=t('nav.reports'); $heading=t('nav.reports'); $sub=t('hr.sub');
require __DIR__.'/header.php';
$unit=' <span>'.tt('unit.mgdl').'</span>';

if($view):
  $p=$all[$pid]; $rp=$p['reports'][$ri];
  // عدد الأيام التقويمية من يوم أول قراءة حتى يوم الإرسال (قد تكون 15 يوماً جزئية لفترة 14×24 ساعة)
  $start=$rp['from']; $end=$rp['to']; $days=(int)round((strtotime('today',$end-1)-strtotime('today',$start))/86400)+1;
  $period=ldate('M d',$start).' – '.ldate('M d, Y',$end-1);
  // كل ما في التقرير محسوب من بيانات المريض المسجلة فعلاً داخل فترة التقرير فقط
  $in=fn($x)=>$x['at']>=$start && $x['at']<$end;
  $rs=array_values(array_filter($p['readings'],$in)); $s=glucoseStats($rs,targets($p));
  $m=array_values(array_filter($p['meals'],$in)); $nm=count($m);
  $avgC=$nm?round(array_sum(array_column($m,'carbs'))/$nm):null;
  $avgD=$nm?round(array_sum(array_map(fn($x)=>$x['after']-$x['before'],$m))/$nm):null;
  $al=array_filter($p['alerts'],$in);
  $ins=array_filter($p['ins'], fn($i)=>is_int($i[1]) && $i[1]>=$start && $i[1]<$end);
?>
  <div class="noprint bar"><a class="btn ghost" href="health_reports.php"><?= tt('hr.back') ?></a>
    <button class="btn" onclick="window.print()"><?= tt('hr.print') ?></button></div>

  <div class="card c-info head">
    <div class="avatar big"><?= h(initials($p['name'])) ?></div>
    <div><b class="nm"><?= h(reportTitle($rp)) ?></b><small><?= h($p['name']) ?> · <?= h(patientMeta($p)) ?></small><small><?= tt('hr.period',['p'=>$period,'doc'=>$doc['name']]) ?></small><?php if($rp['kind']==='first'): ?><small><?= tt('hr.auto') ?></small><?php endif; ?></div>
    <?= statusPill($p['status']) ?>
  </div>

  <section class="stats">
    <div class="card c-avg"><div class="ico"><?= ic('drop') ?></div><div><small><?= tt('card.avg') ?></small><b><?= $s['avg']===null?'—':$s['avg'].$unit ?></b></div></div>
    <div class="card c-ok"><div class="ico"><?= ic('clock') ?></div><div><small><?= tt('card.tir') ?></small><b><?= dash($s['tir'],'%') ?></b></div></div>
    <div class="card c-ctrl"><div class="ico"><?= ic('alert') ?></div><div><small><?= tt('card.high') ?></small><b><?= dash($s['high'],'%') ?></b></div></div>
    <div class="card c-high"><div class="ico"><?= ic('drop') ?></div><div><small><?= tt('card.low') ?></small><b><?= dash($s['low'],'%') ?></b></div></div>
    <div class="card c-info"><div class="ico"><?= ic('report') ?></div><div><small><?= tt('card.total') ?></small><b><?= $s['total'] ?></b></div></div>
  </section>

  <h2 class="sub"><?= tt('chart.daily') ?></h2>
  <?= avgChart(dailyAverages($rs,$days,$end-1), t('chart.daily')) ?>
  <small class="note"><?= tt('chart.band') ?></small>

  <h2 class="sub"><?= tt('hr.meals') ?></h2>
  <p class="txt"><?= $nm ? t('hr.meals_sum',['n'=>$nm,'c'=>$avgC,'d'=>ltr(sprintf('%+d',$avgD))]) : tt('hr.no_meals') ?></p>

  <h2 class="sub"><?= tt('hr.alerts') ?></h2>
  <div class="list">
    <?php foreach($al as $a): ?><div class="row <?= $a['st'] ?>"><div class="who"><div class="ico"><?= ic('alert') ?></div><div><b><?= h(alertTitle($a)) ?></b><small><?= h(ldate('M d, Y · h:i A',$a['at'])) ?></small></div></div><span></span><span></span><span></span></div>
    <?php endforeach; if(!$al) echo '<p class="txt">'.tt('hr.no_alerts').'</p>'; ?>
  </div>

  <h2 class="sub"><?= tt('hr.ins') ?></h2>
  <div class="list">
    <?php foreach($ins as $i): ?><div class="row ok"><div class="who"><div class="ico"><?= ic('steth') ?></div><div><b dir="auto"><?= h($i[0]) ?></b><small><?= h(ldate('M d, Y · h:i A',$i[1])) ?></small></div></div><span></span><span></span><span></span></div>
    <?php endforeach; if(!$ins) echo '<p class="txt">'.tt('hr.no_ins').'</p>'; ?>
  </div>

<?php else:
  $items=[];
  foreach($all as $id=>$p){ if($pid && $pid!==$id) continue;
    foreach($p['reports'] as $i=>$r) $items[]=['pid'=>$id,'i'=>$i,'t'=>reportTitle($r),'kind'=>$r['kind'],'pt'=>$p['name'],'ts'=>$r['at'],'new'=>!reportSeen($id,$r)]; }
  usort($items, fn($a,$b)=>$b['ts']<=>$a['ts']);
?>
  <div class="bar"><h2><?= tt('hr.count',['n'=>count($items)]) ?></h2>
    <form method="get"><select name="p" onchange="this.form.submit()" aria-label="<?= tt('common.select_patient') ?>">
      <option value="0"><?= tt('common.all_patients') ?></option>
      <?php foreach($all as $k=>$x): ?><option value="<?= $k ?>" <?= $pid===$k?'selected':'' ?>><?= h($x['name']) ?></option><?php endforeach; ?>
    </select></form></div>
  <div class="list">
    <?php foreach($items as $it): ?>
      <a class="row pl ok" href="health_reports.php?p=<?= $it['pid'] ?>&r=<?= $it['i'] ?>" data-s="<?= h(mb_strtolower($it['t'].' '.$it['pt'])) ?>">
        <div class="who"><div class="ico"><?= ic('report') ?></div><div><b><?= h($it['t']) ?></b><small><?= h($it['pt']) ?></small></div></div>
        <div class="val"><span><?= h(ldate('M d, Y',$it['ts'])) ?></span></div>
        <div class="stat"><span class="pill b-ok"><?= tt('rep.kind.'.$it['kind']) ?></span><?php if($it['new']): ?> <span class="pill b-new"><?= tt('hr.new') ?></span><?php endif; ?></div><span><?= tt('common.chev') ?></span></a>
    <?php endforeach; if(!$items) echo '<p class="empty">'.tt('hr.none').'</p>'; ?>
  </div>
<?php endif; ?>
<?php require __DIR__.'/footer.php'; ?>

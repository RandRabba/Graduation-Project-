<?php
require_once __DIR__.'/data.php';
$page='stats'; $title=t('nav.stats'); $heading=t('nav.stats'); $sub=t('stat.sub');
require __DIR__.'/header.php';
$ps=getPatients(); $n=count($ps);
foreach($ps as &$p) $p['st']=glucoseStats($p['readings'],targets($p)); unset($p);
// المتوسطات تُحسب فقط من المرضى الذين لديهم قراءات، والوقت ضمن النطاق فقط ممن لديهم بيانات حساس (CGM)
$wd=array_filter($ps, fn($p)=>$p['st']['total']>0); $nd=count($wd);
$avg=$nd?round(array_sum(array_map(fn($p)=>$p['st']['avg'],$wd))/$nd):null;
$wt=array_filter(array_map(fn($p)=>$p['st']['tir'],$wd), fn($v)=>$v!==null);
$tir=$wt?round(array_sum($wt)/count($wt)):null;
$cnt=array_count_values(array_filter(array_column($ps,'status')));
uasort($wd, fn($a,$b)=>($a['st']['tir']??101)<=>($b['st']['tir']??101));
?>
  <section class="stats">
    <div class="card c-info"><div class="ico"><?= ic('users') ?></div><div><small><?= tt('stat.patients') ?></small><b><?= $n ?></b></div></div>
    <div class="card c-avg"><div class="ico"><?= ic('drop') ?></div><div><small><?= tt('card.avg') ?></small><b><?= $avg===null?'—':$avg.' <span>'.tt('unit.mgdl').'</span>' ?></b></div></div>
    <div class="card c-ok"><div class="ico"><?= ic('clock') ?></div><div><small><?= tt('stat.avg_tir') ?></small><b><?= dash($tir,'%') ?></b></div></div>
    <div class="card c-high"><div class="ico"><?= ic('alert') ?></div><div><small><?= tt('stat.crit') ?></small><b><?= $cnt['crit'] ?? 0 ?></b></div></div>
  </section>
  <h2 class="sub"><?= tt('stat.by_status') ?></h2>
  <div class="bars">
    <?php foreach(['ok','ctrl','crit'] as $k): $c=$cnt[$k]??0; ?>
      <div><span><?= h(PST[$k]) ?></span><span class="track"><i class="b-<?= $k ?>" style="width:<?= $n?round($c/$n*100,1):0 ?>%"></i></span><em><?= $c ?></em></div>
    <?php endforeach; ?>
  </div>
  <h2 class="sub"><?= tt('stat.attention') ?></h2>
  <div class="list">
    <?php foreach($wd as $p): ?>
      <a class="row pl <?= $p['status'] ?? 'none' ?>" href="patient.php?id=<?= $p['id'] ?>">
        <div class="who"><div class="avatar"><?= h(initials($p['name'])) ?></div><div><b dir="auto"><?= h($p['name']) ?></b><small><?= h(patientMeta($p)) ?></small></div></div>
        <div class="val"><b><?= dash($p['st']['tir'],'%') ?></b> <span><?= tt('stat.in_range') ?></span></div>
        <div class="stat"><?= statusPill($p['status']) ?><span class="rng"><?= tt('stat.avg',['v'=>$p['st']['avg']]) ?></span></div><span><?= tt('common.chev') ?></span></a>
    <?php endforeach; if(!$wd) echo '<p class="txt">'.tt('stat.none').'</p>'; ?>
  </div>
<?php require __DIR__.'/footer.php'; ?>

<?php
require __DIR__.'/data.php';
header('Content-Type: application/json; charset=utf-8');
$all = getPatients();
$id  = (int)($_GET['patient'] ?? 1);
if (!isset($all[$id])) { http_response_code(404); echo json_encode(['error'=>t('common.not_found')], JSON_UNESCAPED_UNICODE); exit; }
$rs = $all[$id]['readings']; $tg = targets($all[$id]);
// النصوص (المصدر، التصنيف، التاريخ) تُرسل بلغة الطبيبة الحالية. القيم الطبية تبقى كما هي
echo json_encode([
  'patient' => ['id'=>$id,'name'=>$all[$id]['name']],
  'stats'   => glucoseStats($rs, $tg),
  'readings'=> array_map(fn($r) => [
    'pid'=>$id, 'v'=>$r['v'], 'date'=>ldate('M d, Y', $r['at']), 'time'=>ldate('h:i A', $r['at']),
    'src'=>$r['src'], 'icon'=>GSRC[$r['src']][0], 'title'=>GSRC[$r['src']][1], 'sub'=>$r['type'] ?? '',
    'st'=>$r['st'], 'label'=>PST[$r['st']], 'range'=>stRange($r['st'], $tg, (int)$r['v']),
  ], array_slice($rs, 0, 10)),
], JSON_UNESCAPED_UNICODE);
